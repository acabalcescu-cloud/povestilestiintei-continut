<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }
/**
 * Pagina meciului: rezumatul ca în tema demo (sigle, scor, marcatori), apoi cronica și rezumatul video.
 * Un meci construit în Elementor își păstrează pagina.
 */
remove_action( 'atleticos_wrapper_open', 'atleticos_wrapper_open' );
remove_action( 'atleticos_wrapper_close', 'atleticos_wrapper_close' );

get_header();
?>
<div class="lte-text-page inner-page margin-default">
	<?php
	while ( have_posts() ) :
		the_post();
		if ( ps_child_jucator_are_elementor( get_the_ID() ) ) {
			the_content();
		} else {
			echo ps_child_meci_pagina( get_the_ID() ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapat în funcție
		}
	endwhile;
	?>
</div>
<?php
get_footer();

<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }
/**
 * Pagina jucătorului: fișa automată din câmpurile lui. Un jucător cu o pagină reală construită în Elementor își păstrează pagina.
 */
remove_action( 'atleticos_wrapper_open', 'atleticos_wrapper_open' );
remove_action( 'atleticos_wrapper_close', 'atleticos_wrapper_close' );

get_header();
?>
<div class="lte-text-page inner-page margin-default">
	<?php
	while ( have_posts() ) :
		the_post();
		if ( ps_child_jucator_are_elementor( get_the_ID() ) ) {
			the_content();
		} else {
			echo ps_child_jucator_fisa( get_the_ID() ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapat în funcție
		}
	endwhile;
	?>
</div>
<?php
get_footer();

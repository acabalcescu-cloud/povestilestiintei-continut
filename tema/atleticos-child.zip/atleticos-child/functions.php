<?php
/**
 * Poveștile Științei – temă copil pentru Atleticos.
 * Recolorează tema în culorile siglei, fără să modifice tema-părinte.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pluginul LT Core (Unyson) citește $_SESSION fără să pornească sesiunea, iar PHP 8 afișează
 * „Undefined global variable $_SESSION” în subsolul paginii. Îi dăm o valoare goală și
 * nu mai afișăm avertismentele PHP vizitatorilor (rămân în jurnalul serverului).
 */
if ( ! isset( $_SESSION ) ) {
	$_SESSION = array();
}
if ( ! is_admin() ) {
	@ini_set( 'display_errors', '0' );
}

/**
 * Paleta siglei. Schimbă aici dacă vrei alte nuanțe.
 */
function ps_child_colors() {
	return array(
		'main'       => '#0058B0', // albastrul siglei
		'second'     => '#003F80', // albastru închis (hover, accente)
		'gray'       => '#EEF4FA', // albastru foarte deschis (fundaluri)
		'black'      => '#0E1E33', // bleumarin (text, secțiuni închise)
		'black-dark' => '#071A33', // bleumarin închis (subsol, antet închis)
		'white'      => '#FFFFFF',
		'red'        => '#0058B0', // tema folosește „red” ca accent: îl facem albastru
	);
}

/**
 * Stilurile părinte, apoi ale copilului.
 */
add_action( 'wp_enqueue_scripts', 'ps_child_enqueue', 11 );
function ps_child_enqueue() {
	$ver = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'atleticos-parent-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'atleticos-child-style', get_stylesheet_directory_uri() . '/style.css', array( 'atleticos-parent-style' ), $ver );
}

/**
 * Culorile siglei, încărcate după stilurile temei ca să aibă prioritate
 * și față de culorile salvate în Personalizare.
 */
add_action( 'wp_enqueue_scripts', 'ps_child_recolor', 100 );
function ps_child_recolor() {
	$ver = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'ps-recolor', get_stylesheet_directory_uri() . '/recolor.css', array(), $ver );

	$css = ':root{';
	foreach ( ps_child_colors() as $name => $hex ) {
		$css .= '--' . $name . ':' . $hex . ' !important;';
	}
	$css .= '}';
	wp_add_inline_style( 'ps-recolor', $css );
}

/**
 * Aceeași paletă în editorul de blocuri.
 */
add_action( 'after_setup_theme', 'ps_child_editor_palette', 20 );
function ps_child_editor_palette() {
	$c = ps_child_colors();
	add_theme_support(
		'editor-color-palette',
		array(
			array( 'name' => 'Albastru Poveștile Științei', 'slug' => 'main', 'color' => $c['main'] ),
			array( 'name' => 'Albastru închis', 'slug' => 'second', 'color' => $c['second'] ),
			array( 'name' => 'Albastru deschis', 'slug' => 'gray', 'color' => $c['gray'] ),
			array( 'name' => 'Bleumarin', 'slug' => 'black', 'color' => $c['black'] ),
			array( 'name' => 'Alb', 'slug' => 'white', 'color' => $c['white'] ),
		)
	);
}

add_action( 'enqueue_block_editor_assets', 'ps_child_editor_colors' );
function ps_child_editor_colors() {
	$css = ':root{';
	foreach ( ps_child_colors() as $name => $hex ) {
		$css .= '--' . $name . ':' . $hex . ' !important;';
	}
	$css .= '}';
	wp_register_style( 'ps-editor-colors', false );
	wp_enqueue_style( 'ps-editor-colors' );
	wp_add_inline_style( 'ps-editor-colors', $css );
}

/**
 * Culoarea barei de adrese pe telefoane.
 */
add_action( 'wp_head', 'ps_child_theme_color', 1 );
function ps_child_theme_color() {
	echo '<meta name="theme-color" content="' . esc_attr( ps_child_colors()['main'] ) . '">' . "\n";
}

/**
 * Siglele cluburilor prin REST (taxonomia lte-football-club nu e în REST).
 * GET  /wp-json/ps/v1/clubs                         – lista cluburilor cu sigla actuală
 * POST /wp-json/ps/v1/club-logo {term_id, attachment_id} – setează sigla
 * Doar pentru utilizatori care pot gestiona categoriile (administratori, editori).
 */
add_action( 'rest_api_init', 'ps_child_club_routes' );
function ps_child_club_routes() {
	$can = function () {
		return current_user_can( 'manage_categories' );
	};

	register_rest_route(
		'ps/v1',
		'/clubs',
		array(
			'methods'             => 'GET',
			'permission_callback' => $can,
			'callback'            => function () {
				$out   = array();
				$terms = get_terms( array( 'taxonomy' => 'lte-football-club', 'hide_empty' => false ) );
				foreach ( (array) $terms as $t ) {
					$logo  = function_exists( 'fw_get_db_term_option' ) ? fw_get_db_term_option( $t->term_id, 'lte-football-club', 'logo' ) : null;
					$out[] = array( 'id' => $t->term_id, 'name' => $t->name, 'logo' => $logo );
				}
				return $out;
			},
		)
	);

	register_rest_route(
		'ps/v1',
		'/club-logo',
		array(
			'methods'             => 'POST',
			'permission_callback' => $can,
			'callback'            => function ( WP_REST_Request $req ) {
				$term_id = (int) $req['term_id'];
				$att_id  = (int) $req['attachment_id'];
				if ( ! get_term( $term_id, 'lte-football-club' ) || ! wp_get_attachment_url( $att_id ) ) {
					return new WP_Error( 'ps_bad_ids', 'Club sau imagine inexistentă.', array( 'status' => 400 ) );
				}
				if ( ! function_exists( 'fw_set_db_term_option' ) ) {
					return new WP_Error( 'ps_no_unyson', 'Unyson nu e activ.', array( 'status' => 500 ) );
				}
				$logo = array( 'attachment_id' => $att_id, 'url' => wp_get_attachment_url( $att_id ) );
				fw_set_db_term_option( $term_id, 'lte-football-club', 'logo', $logo );
				return array( 'id' => $term_id, 'logo' => fw_get_db_term_option( $term_id, 'lte-football-club', 'logo' ) );
			},
		)
	);
}

/**
 * Clasamentul Superligii, în formatul Sofascore.
 * Sofascore blochează serverul (403), așa că îl trimite scriptul clasament.sh rulat de pe Mac
 * la POST /wp-json/ps/v1/clasament. Rămâne afișat ultimul clasament primit.
 * Pe pagină: shortcode-ul [ps_clasament] (în Elementor, widgetul „Shortcode”).
 */
define( 'PS_SOFA_TEAM', 116223 );     // Universitatea Craiova

function ps_child_sofa_clubs() {
	// ID Sofascore => ID termen club pe site.
	return array(
		381792 => 11, // ML Vitebsk
		116223 => 12, // Universitatea Craiova
		7734 => 13, // FC Universitatea Cluj
		204657 => 14, // UTA Arad
		3273 => 15, // Levski Sofia
		3292 => 16, // FC Dinamo București
		25856 => 17, // FC Petrolul Ploiești
		2244 => 18, // Kuopion Palloseura
		116221 => 19, // FC Argeș Pitești
		3291 => 20, // SC Oțelul Galați
		262229 => 21, // FC Ararat-Armenia
		44255 => 22, // FC Voluntari
		295403 => 23, // FC Rapid București
		485425 => 24, // ACS FC Bacău
		148278 => 25, // FC Corvinul Hunedoara
		3301 => 26, // FCSB
		283972 => 27, // FK Csíkszereda Miercurea Ciuc
		2859 => 28, // Getafe
		3294 => 29, // FCV Farul Constanța
		37946 => 30, // Inter Club d'Escaldes
		189789 => 31, // Sepsi OSK Sfântu Gheorghe
		24798 => 32, // FC Botoșani
		264619 => 33, // KF Egnatia
		5287 => 34, // CFR 1907 Cluj
		30 => 35, // Brighton & Hove Albion
		5172 => 36, // FC Kairat Almaty
		1284 => 37, // FC København
	);
}

// Verificarea automată din versiunea 1.2.x nu mai e folosită.
add_action( 'init', 'ps_child_unschedule_standings' );
function ps_child_unschedule_standings() {
	if ( wp_next_scheduled( 'ps_child_update_standings' ) ) {
		wp_clear_scheduled_hook( 'ps_child_update_standings' );
	}
	delete_option( 'ps_standings_error' );
}

/**
 * Sigla unei echipe: a clubului de pe site dacă există, altfel o descarcă o singură dată în Media.
 */
function ps_child_team_logo( $sofa_id, $name ) {
	$clubs = ps_child_sofa_clubs();
	if ( isset( $clubs[ $sofa_id ] ) && function_exists( 'fw_get_db_term_option' ) ) {
		$logo = fw_get_db_term_option( $clubs[ $sofa_id ], 'lte-football-club', 'logo' );
		if ( ! empty( $logo['url'] ) ) {
			return $logo['url'];
		}
	}

	$extra = get_option( 'ps_sofa_logos', array() );
	if ( ! empty( $extra[ $sofa_id ] ) && wp_get_attachment_url( $extra[ $sofa_id ] ) ) {
		return wp_get_attachment_url( $extra[ $sofa_id ] );
	}

	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$tmp = download_url( 'https://img.sofascore.com/api/v1/team/' . (int) $sofa_id . '/image', 20 );
	if ( is_wp_error( $tmp ) ) {
		return '';
	}
	$att = media_handle_sideload( array( 'name' => 'sigla-sofa-' . (int) $sofa_id . '.png', 'tmp_name' => $tmp ), 0, $name );
	if ( is_wp_error( $att ) ) {
		@unlink( $tmp );
		return '';
	}
	$extra[ $sofa_id ] = $att;
	update_option( 'ps_sofa_logos', $extra, false );
	return wp_get_attachment_url( $att );
}

/**
 * Salvează clasamentul primit (răspunsul Sofascore pentru standings/total).
 */
function ps_child_save_standings( $data, $season ) {
	$clubs  = ps_child_sofa_clubs();
	$groups = array();
	foreach ( $data['standings'] as $st ) {
		$rows = array();
		foreach ( $st['rows'] as $r ) {
			$sid    = (int) $r['team']['id'];
			$name   = isset( $clubs[ $sid ] ) && get_term( $clubs[ $sid ], 'lte-football-club' ) ? get_term( $clubs[ $sid ], 'lte-football-club' )->name : $r['team']['name'];
			$rows[] = array(
				'id'   => $sid,
				'pos'  => (int) $r['position'],
				'name' => $name,
				'logo' => ps_child_team_logo( $sid, $name ),
				'pl'   => (int) $r['matches'],
				'w'    => (int) $r['wins'],
				'd'    => (int) $r['draws'],
				'l'    => (int) $r['losses'],
				'gd'   => (int) $r['scoresFor'] - (int) $r['scoresAgainst'],
				'pts'  => (int) $r['points'],
			);
		}
		$groups[] = array( 'name' => isset( $st['name'] ) ? $st['name'] : '', 'rows' => $rows );
	}

	update_option( 'ps_standings', array( 'season' => $season, 'updated' => time(), 'groups' => $groups ), false );
}

/**
 * [ps_clasament limit="12" buton="Toate meciurile" link="/meciuri/"]
 * Același HTML ca widgetul „League Table” al temei, deci același aspect.
 */
add_shortcode( 'ps_clasament', 'ps_child_standings_shortcode' );
function ps_child_standings_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'limit' => 0, 'buton' => '', 'link' => '' ), $atts );
	$data = get_option( 'ps_standings' );
	if ( empty( $data['groups'] ) ) {
		return '<p>Clasamentul se încarcă în curând.</p>';
	}

	$out = '';
	foreach ( $data['groups'] as $g ) {
		if ( count( $data['groups'] ) > 1 && $g['name'] ) {
			$out .= '<h6 class="ps-clasament-grupa">' . esc_html( $g['name'] ) . '</h6>';
		}
		$out .= '<table class="lte-football-table"><thead><tr><th></th><th></th>'
			. '<th class="lte-name">Echipa</th><th>M</th><th>V</th><th>E</th><th>Î</th><th>GD</th><th>Pct</th></tr></thead><tbody>';
		$rows = $atts['limit'] ? array_slice( $g['rows'], 0, (int) $atts['limit'] ) : $g['rows'];
		foreach ( $rows as $r ) {
			$out .= '<tr' . ( PS_SOFA_TEAM === $r['id'] ? ' class="ps-noi"' : '' ) . '>'
				. '<td class="lte-row"><span></span>' . (int) $r['pos'] . '</td>'
				. '<td class="lte-club-logo">' . ( $r['logo'] ? '<img src="' . esc_url( $r['logo'] ) . '" alt="' . esc_attr( $r['name'] ) . '">' : '' ) . '</td>'
				. '<td class="lte-name">' . esc_html( $r['name'] ) . '</td>'
				. '<td class="lte-rate">' . (int) $r['pl'] . '</td>'
				. '<td class="lte-rate">' . (int) $r['w'] . '</td>'
				. '<td class="lte-rate">' . (int) $r['d'] . '</td>'
				. '<td class="lte-rate">' . (int) $r['l'] . '</td>'
				. '<td class="lte-rate">' . (int) $r['gd'] . '</td>'
				. '<td class="lte-summary">' . (int) $r['pts'] . '</td></tr>';
		}
		$out .= '</tbody></table>';
	}

	if ( $atts['buton'] && function_exists( 'lte_button_sc' ) ) {
		$out .= '<div class="lte-more">' . lte_button_sc( array( 'header' => esc_html( $atts['buton'] ), 'href' => esc_url( $atts['link'] ), 'color' => 'transparent', 'size' => 'xs' ) ) . '</div>';
	}
	return $out;
}

/**
 * GET  /wp-json/ps/v1/clasament – ultima actualizare (public)
 * POST /wp-json/ps/v1/clasament – {season, standings} trimis de clasament.sh (administratori)
 */
add_action( 'rest_api_init', 'ps_child_standings_routes' );
function ps_child_standings_routes() {
	$status = function () {
		$data = get_option( 'ps_standings' );
		return array(
			'sezon'      => isset( $data['season'] ) ? $data['season'] : null,
			'actualizat' => ! empty( $data['updated'] ) ? wp_date( 'Y-m-d H:i', $data['updated'] ) : null,
			'echipe'     => ! empty( $data['groups'] ) ? array_sum( array_map( function ( $g ) { return count( $g['rows'] ); }, $data['groups'] ) ) : 0,
		);
	};
	register_rest_route( 'ps/v1', '/clasament', array(
		array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => $status,
		),
		array(
			'methods'             => 'POST',
			'permission_callback' => function () { return current_user_can( 'manage_options' ); },
			'callback'            => function ( WP_REST_Request $req ) use ( $status ) {
				$body = $req->get_json_params();
				if ( empty( $body['standings'][0]['rows'] ) ) {
					return new WP_Error( 'ps_bad_standings', 'Clasament gol sau în alt format.', array( 'status' => 400 ) );
				}
				ps_child_save_standings( $body, isset( $body['season'] ) ? sanitize_text_field( $body['season'] ) : '' );
				return $status();
			},
		),
	) );
}

/**
 * Traducerea în română a temei Atleticos și a pluginului LTE-Ext (acestea nu au ro_RO).
 * Fișierele .po din languages/ se pot edita, apoi se recompilează .mo.
 */
add_action( 'after_setup_theme', 'ps_child_load_translations', 5 );
function ps_child_load_translations() {
	$locale = determine_locale();
	foreach ( array( 'atleticos', 'lte-ext' ) as $domain ) {
		$mo = get_stylesheet_directory() . '/languages/' . $domain . '-' . $locale . '.mo';
		if ( file_exists( $mo ) ) {
			load_textdomain( $domain, $mo );
		}
	}
}

/**
 * „Următorul meci” (widgetul Upcoming) arată meciul zilei până la miezul nopții.
 * Îl mutăm pe meciul următor la 2 ore după ora de start.
 */
add_action( 'pre_get_posts', 'ps_child_upcoming_after_kickoff' );
function ps_child_upcoming_after_kickoff( $query ) {
	if ( 'lte-football' !== $query->get( 'post_type' ) ) {
		return;
	}
	$dq = $query->get( 'date_query' );
	if ( is_array( $dq ) && isset( $dq['after'] ) && 'today' === $dq['after'] ) {
		$dq['after'] = wp_date( 'Y-m-d H:i:s', time() - 2 * HOUR_IN_SECONDS );
		$query->set( 'date_query', $dq );
	}
}

/**
 * Cronici și scoruri automate.
 * O sesiune Claude programată scrie după fiecare meci cronica, coperta și scorul într-un depozit GitHub public.
 * Site-ul verifică depozitul la 15 minute: cronicile intră ca ciorne (cu email de anunț), scorurile direct în meci.
 *
 * Depozit: index.json = { "cronici": [ "cronici/<id>.json", ... ] }
 * cronici/<id>.json = { id, titlu, rezumat, continut (HTML), categorie, etichete[], imagine,
 *                      meci: { data: "Y-m-d", scor: [gazde, oaspeți], marcatori?: { gazde: [{nume, minut}], oaspeti: [...] },
 *                              statistici?: [[„Posesia mingii”, „54%”, „46%”], ...], sursa_statistici?: „LPF” | „UEFA” } }
 * Opțional: data_publicare ("Y-m-d H:i", ora României) și anunt: false (fără email).
 * Autor (opțional): autor: { login, nume } – utilizatorul e creat cu rolul Autor dacă nu există.
 * Rezumat video: { id, tip: "video", titlu, rezumat, video_url, durata ("mm:ss"), imagine_url, categorie, etichete[], data_publicare }
 */
define( 'PS_CONTENT_REPO', 'acabalcescu-cloud/povestilestiintei-continut' ); // gol = oprit
define( 'PS_CONTENT_BRANCH', 'main' );

add_filter( 'cron_schedules', 'ps_child_cron_15m' );
function ps_child_cron_15m( $schedules ) {
	$schedules['ps_15m'] = array( 'interval' => 15 * MINUTE_IN_SECONDS, 'display' => 'La 15 minute' );
	return $schedules;
}

add_action( 'init', 'ps_child_schedule_content' );
function ps_child_schedule_content() {
	if ( PS_CONTENT_REPO && ! wp_next_scheduled( 'ps_child_import_content' ) ) {
		wp_schedule_event( time() + 60, 'ps_15m', 'ps_child_import_content' );
	}
}

function ps_child_repo_url( $path ) {
	return 'https://raw.githubusercontent.com/' . PS_CONTENT_REPO . '/' . PS_CONTENT_BRANCH . '/' . ltrim( $path, '/' );
}

function ps_child_repo_json( $path ) {
	$res = wp_remote_get( ps_child_repo_url( $path ), array( 'timeout' => 20 ) );
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	if ( 200 !== wp_remote_retrieve_response_code( $res ) ) {
		return new WP_Error( 'ps_repo_http', 'GitHub a răspuns ' . wp_remote_retrieve_response_code( $res ) . ' la ' . $path );
	}
	$data = json_decode( wp_remote_retrieve_body( $res ), true );
	return is_array( $data ) ? $data : new WP_Error( 'ps_repo_json', 'JSON invalid în ' . $path );
}

/**
 * Pune scorul în meciul de la data respectivă (pe site e un singur meci pe zi).
 * Titlul îl refac funcția temei, la fel ca la salvarea din admin.
 */
function ps_child_set_match_score( $date, $score ) {
	$ts = strtotime( $date );
	if ( ! $ts || ! is_array( $score ) || 2 !== count( $score ) || ! function_exists( 'fw_set_db_post_option' ) ) {
		return false;
	}
	$posts = get_posts( array(
		'post_type'   => 'lte-football',
		'post_status' => array( 'publish', 'future' ),
		'numberposts' => 1,
		'date_query'  => array( array( 'year' => gmdate( 'Y', $ts ), 'month' => gmdate( 'n', $ts ), 'day' => gmdate( 'j', $ts ) ) ),
	) );
	if ( ! $posts ) {
		return false;
	}
	$id = $posts[0]->ID;
	fw_set_db_post_option( $id, 'team-1-score', (string) (int) $score[0] );
	fw_set_db_post_option( $id, 'team-2-score', (string) (int) $score[1] );
	if ( function_exists( 'lte_football_save_postdata' ) ) {
		lte_football_save_postdata( $id, get_post( $id ), true );
	}
	return $id;
}

/**
 * Utilizatorul autor după login; dacă nu există, îl creăm cu rolul Autor (fără email: George i-l pune din admin).
 */
function ps_child_author( $autor ) {
	$login = sanitize_user( $autor['login'], true );
	$user  = get_user_by( 'login', $login );
	if ( $user ) {
		return (int) $user->ID;
	}
	$nume  = isset( $autor['nume'] ) ? sanitize_text_field( $autor['nume'] ) : $login;
	$parts = explode( ' ', $nume, 2 );
	$id    = wp_insert_user( array(
		'user_login'   => $login,
		'user_pass'    => wp_generate_password( 24 ),
		'display_name' => $nume,
		'nickname'     => $nume,
		'first_name'   => $parts[0],
		'last_name'    => isset( $parts[1] ) ? $parts[1] : '',
		'role'         => 'author',
	) );
	return is_wp_error( $id ) ? 0 : (int) $id;
}

function ps_child_import_item( $item ) {
	$existing = get_posts( array( 'post_type' => 'post', 'post_status' => 'any', 'meta_key' => '_ps_sursa', 'meta_value' => $item['id'], 'numberposts' => 1, 'fields' => 'ids' ) );
	if ( $existing ) {
		return 0;
	}

	// Fără autor anume, articolele sunt semnate de George (contul UCV_George).
	$george  = get_user_by( 'login', 'UCV_George' );
	$admins  = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID' ) );
	$author  = $george ? $george->ID : ( $admins ? (int) $admins[0] : 1 );
	if ( ! empty( $item['autor']['login'] ) ) {
		$author = ps_child_author( $item['autor'] ) ?: $author;
	}
	$cat_ids = array();
	if ( ! empty( $item['categorie'] ) ) {
		$cat = get_term_by( 'name', $item['categorie'], 'category' );
		if ( ! $cat ) {
			$new = wp_insert_term( $item['categorie'], 'category' );
			$cat_ids[] = is_wp_error( $new ) ? 0 : $new['term_id'];
		} else {
			$cat_ids[] = $cat->term_id;
		}
	}

	$postarr = array(
		'post_type'     => 'post',
		// Din 1.17: articolele din depozit se publică direct (cererea lui George, 31 oct 2026).
		// Cu "status": "draft" în JSON, articolul rămâne ciornă (pentru texte care așteaptă aprobarea).
		// Întâi ciornă: coperta se atașează înainte de publicare, ca Facebook (WP2Social) să găsească imaginea articolului.
		'post_status'   => 'draft',
		'post_author'   => $author,
		'post_title'    => wp_strip_all_tags( $item['titlu'] ),
		'post_excerpt'  => isset( $item['rezumat'] ) ? wp_strip_all_tags( $item['rezumat'] ) : '',
		'post_content'  => isset( $item['tip'] ) && 'video' === $item['tip'] ? esc_url_raw( $item['video_url'] ) : wp_kses_post( $item['continut'] ),
		'post_category' => array_filter( $cat_ids ),
		'tags_input'    => isset( $item['etichete'] ) ? (array) $item['etichete'] : array(),
		'meta_input'    => array( '_ps_sursa' => $item['id'] ),
	);
	// Cronicile din trecut poartă data de după meci; o păstrează și la publicare.
	if ( ! empty( $item['data_publicare'] ) && strtotime( $item['data_publicare'] ) ) {
		// O dată din viitor ar programa articolul; îl limităm la ora curentă, ca să apară imediat.
		$postarr['post_date']     = gmdate( 'Y-m-d H:i:s', min( strtotime( $item['data_publicare'] ), strtotime( current_time( 'mysql' ) ) ) );
		$postarr['post_date_gmt'] = get_gmt_from_date( $postarr['post_date'] );
		$postarr['edit_date']     = true;
	}
	$post_id = wp_insert_post( $postarr, true );
	if ( is_wp_error( $post_id ) ) {
		return $post_id;
	}
	if ( ! empty( $postarr['edit_date'] ) ) {
		update_post_meta( $post_id, '_ps_data_publicare', $postarr['post_date'] );
	}

	if ( isset( $item['tip'] ) && 'video' === $item['tip'] ) {
		set_post_format( $post_id, 'video' );
		if ( ! empty( $item['durata'] ) && function_exists( 'fw_set_db_post_option' ) ) {
			fw_set_db_post_option( $post_id, 'video-length', sanitize_text_field( $item['durata'] ) );
		}
	}

	$image_url = ! empty( $item['imagine_url'] ) ? $item['imagine_url'] : ( ! empty( $item['imagine'] ) ? ps_child_repo_url( 'cronici/' . $item['imagine'] ) : '' );
	if ( $image_url ) {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$att = media_sideload_image( $image_url, $post_id, $item['titlu'], 'id' );
		if ( ! is_wp_error( $att ) ) {
			set_post_thumbnail( $post_id, $att );
		}
	}

	if ( ! ( isset( $item['status'] ) && 'draft' === $item['status'] ) ) {
		wp_update_post( array( 'ID' => $post_id, 'post_status' => 'publish' ) );
	}

	if ( isset( $item['anunt'] ) && false === $item['anunt'] ) {
		return $post_id;
	}
	wp_mail(
		get_option( 'admin_email' ),
		'Articol nou publicat: ' . wp_strip_all_tags( $item['titlu'] ),
		"A fost publicat un articol nou pe site.\n\nÎl poți corecta aici: " . admin_url( 'post.php?post=' . $post_id . '&action=edit' )
	);
	return $post_id;
}

add_action( 'ps_child_import_content', 'ps_child_import_content' );
function ps_child_import_content() {
	if ( ! PS_CONTENT_REPO ) {
		return;
	}
	$log   = array( 'verificat' => time(), 'importate' => array(), 'scoruri' => array(), 'erori' => array() );
	$index = ps_child_repo_json( 'index.json' );
	if ( is_wp_error( $index ) ) {
		$log['erori'][] = $index->get_error_message();
		update_option( 'ps_content_log', $log, false );
		return;
	}

	$done = get_option( 'ps_content_done', array() );
	foreach ( isset( $index['cronici'] ) ? (array) $index['cronici'] : array() as $path ) {
		if ( in_array( $path, $done, true ) ) {
			continue;
		}
		$item = ps_child_repo_json( $path );
		$is_video = is_array( $item ) && isset( $item['tip'] ) && 'video' === $item['tip'];
		if ( is_wp_error( $item ) || empty( $item['id'] ) || empty( $item['titlu'] ) || ( $is_video ? empty( $item['video_url'] ) : empty( $item['continut'] ) ) ) {
			$log['erori'][] = is_wp_error( $item ) ? $item->get_error_message() : 'Cronică incompletă: ' . $path;
			continue;
		}
		if ( ! empty( $item['meci']['data'] ) && isset( $item['meci']['scor'] ) ) {
			$match = ps_child_set_match_score( $item['meci']['data'], $item['meci']['scor'] );
			$log['scoruri'][] = $match ? $item['meci']['data'] . ' → meciul ' . $match : 'Niciun meci pe ' . $item['meci']['data'];
			if ( $match && ! empty( $item['meci']['marcatori'] ) ) {
				ps_child_set_marcatori( $match, $item['meci']['marcatori'] );
			}
			if ( $match && ! empty( $item['meci']['statistici'] ) ) {
				ps_child_set_statistici( $match, $item['meci']['statistici'], $item['meci']['sursa_statistici'] ?? 'LPF' );
			}
		}
		$post = ps_child_import_item( $item );
		if ( is_wp_error( $post ) ) {
			$log['erori'][] = $path . ': ' . $post->get_error_message();
			continue;
		}
		$log['importate'][] = $item['id'] . ( $post ? ' → ' . get_post_status( $post ) . ' ' . $post : ' (exista deja)' );
		$done[] = $path;
	}
	update_option( 'ps_content_done', $done, false );
	update_option( 'ps_content_log', $log, false );
}

/**
 * GET  /wp-json/ps/v1/continut – ultima verificare (public)
 * POST /wp-json/ps/v1/continut – verifică acum (administratori)
 */
add_action( 'rest_api_init', 'ps_child_content_routes' );
function ps_child_content_routes() {
	$status = function () {
		$log = get_option( 'ps_content_log', array() );
		return array(
			'depozit'    => PS_CONTENT_REPO ?: null,
			'verificat'  => ! empty( $log['verificat'] ) ? wp_date( 'Y-m-d H:i', $log['verificat'] ) : null,
			'importate'  => isset( $log['importate'] ) ? $log['importate'] : array(),
			'scoruri'    => isset( $log['scoruri'] ) ? $log['scoruri'] : array(),
			'erori'      => isset( $log['erori'] ) ? $log['erori'] : array(),
			'urmatoarea' => wp_next_scheduled( 'ps_child_import_content' ) ? wp_date( 'Y-m-d H:i', wp_next_scheduled( 'ps_child_import_content' ) ) : null,
		);
	};
	register_rest_route( 'ps/v1', '/continut', array(
		array( 'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => $status ),
		array(
			'methods'             => 'POST',
			'permission_callback' => function () { return current_user_can( 'manage_options' ); },
			'callback'            => function () use ( $status ) {
				ps_child_import_content();
				return $status();
			},
		),
	) );
}

/**
 * GET /wp-json/ps/v1/meciuri – meciurile de pe site (public; aceleași date ca pe pagini).
 */
add_action( 'rest_api_init', 'ps_child_matches_route' );
function ps_child_matches_route() {
	register_rest_route( 'ps/v1', '/meciuri', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function () {
			$out = array();
			foreach ( get_posts( array( 'post_type' => 'lte-football', 'post_status' => array( 'publish', 'future' ), 'numberposts' => -1, 'orderby' => 'date', 'order' => 'ASC' ) ) as $p ) {
				$o     = function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( $p->ID ) : array();
				$club  = function ( $id ) { $t = get_term( (int) $id, 'lte-football-club' ); return $t && ! is_wp_error( $t ) ? $t->name : ''; };
				$types = wp_get_post_terms( $p->ID, 'lte-football-type', array( 'fields' => 'names' ) );
				$out[] = array(
					'id'          => $p->ID,
					'data'        => isset( $o['date'] ) ? $o['date'] : get_the_date( 'Y/m/d H:i', $p ),
					'competitie'  => is_wp_error( $types ) ? '' : implode( ', ', $types ),
					'gazde'       => $club( isset( $o['team-1'] ) ? $o['team-1'] : 0 ),
					'oaspeti'     => $club( isset( $o['team-2'] ) ? $o['team-2'] : 0 ),
					'scor'        => 'publish' === $p->post_status ? (int) $o['team-1-score'] . '-' . (int) $o['team-2-score'] : null,
					'stadion'     => isset( $o['venue'] ) ? $o['venue'] : '',
					'stare'       => $p->post_status,
				);
			}
			return $out;
		},
	) );
}

/**
 * [ps_stiri mari="2" mici="4"] – ca în demo-ul temei: primele articole mari, următoarele mici, cu poza în stânga.
 * Folosește șabloanele temei (tmpl/post-formats/list), deci arată ca widgetul Blog.
 */
add_shortcode( 'ps_stiri', 'ps_child_news_shortcode' );
function ps_child_news_shortcode( $atts ) {
	$atts  = shortcode_atts( array( 'mari' => 2, 'mici' => 4, 'categorie' => '' ), $atts );
	$query = new WP_Query( array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => (int) $atts['mari'] + (int) $atts['mici'],
		'orderby'             => 'date',
		'order'               => 'DESC',
		'ignore_sticky_posts' => true,
		'category_name'       => $atts['categorie'],
		'category__not_in'    => array_filter( array( (int) get_cat_ID( 'Poveștile lui Florin' ), (int) get_cat_ID( 'Penalty cu George' ) ) ),
		// Rezumatele video au secțiunea lor ([ps_video]), articolele lui Florin pe a lor ([ps_florin]).
		'tax_query'           => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => array( 'post-format-video' ), 'operator' => 'NOT IN' ) ),
	) );
	if ( ! $query->have_posts() ) {
		return '';
	}

	ob_start();
	$x = 0;
	while ( $query->have_posts() ) {
		$query->the_post();
		$x++;
		$mare = $x <= (int) $atts['mari'];
		if ( 1 === $x ) {
			set_query_var( 'atleticos_layout', 'posts' );
			set_query_var( 'lte_display_excerpt', true );
			set_query_var( 'lte_sc_excerpt_size', 25 );
			echo '<div class="blog lte-blog-sc row centered layout-posts">';
		}
		if ( (int) $atts['mari'] + 1 === $x ) {
			set_query_var( 'atleticos_layout', 'posts-left' );
			set_query_var( 'lte_display_excerpt', false );
			echo '</div><div class="blog lte-blog-sc row centered layout-posts-left">';
		}
		echo '<div class="items col-lg-6 col-md-6 col-sm-12 col-ms-12 col-xs-12">';
		get_template_part( 'tmpl/post-formats/list', get_post_format() );
		echo '</div>';
	}
	echo '</div><div class="clearfix"></div>';
	wp_reset_postdata();
	set_query_var( 'atleticos_layout', false );
	set_query_var( 'lte_display_excerpt', false );
	set_query_var( 'lte_sc_excerpt_size', false );
	return ob_get_clean();
}

/**
 * [ps_video limita="5"] – rezumatele video, ca secțiunea „Match Highlights” din demo:
 * un video mare în stânga, patru mici în dreapta. Clic pe imagine = video în pop-up (tema).
 */
add_shortcode( 'ps_video', 'ps_child_video_shortcode' );
function ps_child_video_shortcode( $atts ) {
	$atts  = shortcode_atts( array( 'limita' => 5 ), $atts );
	$query = new WP_Query( array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => (int) $atts['limita'],
		'ignore_sticky_posts' => true,
		'tax_query'           => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => array( 'post-format-video' ) ) ),
	) );
	if ( ! $query->have_posts() ) {
		return '';
	}

	ob_start();
	echo '<div class="blog lte-blog-sc lte-grid-bg ps-video row">';
	$x = 0;
	while ( $query->have_posts() ) {
		$query->the_post();
		$x++;
		if ( 1 === $x ) {
			set_query_var( 'atleticos_layout', 'posts' );
			set_query_var( 'lte_display_excerpt', true );
			set_query_var( 'lte_sc_excerpt_size', 30 );
			echo '<div class="ps-video-mare col-lg-6 col-md-12 col-xs-12">';
		}
		if ( 2 === $x ) {
			set_query_var( 'lte_display_excerpt', false );
			echo '</div><div class="ps-video-mici col-lg-6 col-md-12 col-xs-12"><div class="row">';
		}
		echo $x > 1 ? '<div class="items col-md-6 col-sm-6 col-xs-12">' : '<div class="items">';
		get_template_part( 'tmpl/post-formats/list', 'video' );
		echo '</div>';
	}
	echo $x > 1 ? '</div></div></div>' : '</div></div>';
	wp_reset_postdata();
	set_query_var( 'atleticos_layout', false );
	set_query_var( 'lte_display_excerpt', false );
	set_query_var( 'lte_sc_excerpt_size', false );
	return ob_get_clean();
}

/**
 * [ps_florin limita="12"] – „Poveștile lui Florin”: carusel pe toată lățimea, câte un card pe articol,
 * cu fotografia lui Florin Stancu și titlul, ca rubricile de opinie din presa sportivă.
 */
add_shortcode( 'ps_florin', 'ps_child_florin_shortcode' );
function ps_child_florin_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'limita' => 12 ), $atts );
	$cat  = (int) get_cat_ID( 'Poveștile lui Florin' );
	if ( ! $cat ) {
		return '';
	}
	$query = new WP_Query( array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => (int) $atts['limita'],
		'cat'                 => $cat,
		'ignore_sticky_posts' => true,
	) );
	if ( ! $query->have_posts() ) {
		return '';
	}

	$foto = esc_url( get_stylesheet_directory_uri() . '/assets/florin-stancu-2026.png?v=' . filemtime( get_stylesheet_directory() . '/assets/florin-stancu-2026.png' ) );
	ob_start();
	echo '<div class="ps-florin"><button type="button" class="ps-florin-nav ps-florin-prev" aria-label="Înapoi">&larr;</button><div class="ps-florin-track">';
	while ( $query->have_posts() ) {
		$query->the_post();
		echo '<a class="ps-florin-card" href="' . esc_url( get_permalink() ) . '">'
			. '<img class="ps-florin-foto" src="' . $foto . '" alt="Florin Stancu" loading="lazy">'
			. '<span class="ps-florin-text"><span class="ps-florin-autor">Florin Stancu</span>'
			. '<span class="ps-florin-titlu">' . esc_html( get_the_title() ) . '</span>'
			. '<span class="ps-florin-data">' . esc_html( get_the_date() ) . '</span></span></a>';
	}
	echo '</div><button type="button" class="ps-florin-nav ps-florin-next" aria-label="Înainte">&rarr;</button></div>';
	wp_reset_postdata();
	add_action( 'wp_footer', 'ps_child_florin_script', 99 );
	return ob_get_clean();
}

function ps_child_florin_script() {
	?>
	<script>
	document.querySelectorAll('.ps-florin').forEach(function (box) {
		var track = box.querySelector('.ps-florin-track');
		var step = function () { var c = track.querySelector('.ps-florin-card'); return c ? c.offsetWidth + 24 : 300; };
		box.querySelector('.ps-florin-prev').addEventListener('click', function () { track.scrollBy({ left: -step(), behavior: 'smooth' }); });
		box.querySelector('.ps-florin-next').addEventListener('click', function () { track.scrollBy({ left: step(), behavior: 'smooth' }); });
	});
	</script>
	<?php
}

/**
 * [ps_istorie] – pagina „Repere istorice” (1948–2026): palmares, linia timpului pe epoci,
 * Craiova Maxima, legendele Științei și anul 2026. Fără perioada 1994–2012.
 */
function ps_child_istorie_data() {
	return array(
		'Începuturile' => array(
			array( '1948', 'Totul începe cu studenții', 'Echipa ia naștere sub numele UNSR Craiova, pe lângă primul institut universitar al orașului. Primul meci oficial se joacă pe 5 septembrie 1948, la Filiași.', false ),
			array( '1950', 'CSU Craiova', 'Echipa studenților devine CSU Craiova.', false ),
			array( '1953', 'Se naște Știința', 'Apare numele Știința Craiova, cel care va rămâne pentru totdeauna în inimile suporterilor.', false ),
			array( '1964', 'Prima promovare în Divizia A', 'Știința câștigă Divizia B în sezonul 1963–1964, după o luptă strânsă pentru promovare, și ajunge pentru prima dată în prima ligă.', false ),
			array( '1966', 'Universitatea Craiova', 'În vara lui 1966, clubul adoptă numele Universitatea Craiova.', false ),
		),
		'Anii de aur' => array(
			array( '1967', 'Oblemenco, golgheterul României', 'Ion Oblemenco devine golgheterul campionatului, iar Craiova își anunță ambițiile.', false ),
			array( '1974', 'Primul titlu de campioană', 'Sub comanda lui Constantin Cernăianu și Constantin Oțet, Universitatea Craiova devine campioana României, cu un punct înaintea lui Dinamo. Poetul Adrian Păunescu îi spune atunci „Campioana unei mari iubiri”.', true ),
			array( '1977', 'Prima Cupă a României', 'Primul trofeu de Cupă din istoria clubului.', true ),
			array( '1978', 'A doua Cupă, consecutiv', 'Știința păstrează trofeul și câștigă Cupa României pentru al doilea an la rând.', true ),
			array( '1979', 'Leeds United, eliminată', 'În Cupa UEFA, Craiova învinge Leeds United cu 2–0 acasă și 2–0 în Anglia: prima echipă românească ce elimină o formație engleză în cupele europene.', false ),
			array( '1980', 'Al doilea titlu', 'Al doilea titlu de campioană a României.', true ),
			array( '1981', 'Primul event', 'Campionat și Cupa României în același sezon: primul event din istoria clubului.', true ),
			array( '1982', 'Sferturi în Cupa Campionilor', 'Știința ajunge în sferturile Cupei Campionilor Europeni, unde este oprită de Bayern München, 1–3 la general.', false ),
			array( '1983', 'Semifinala Cupei UEFA', 'După Fiorentina, Bordeaux și Kaiserslautern, Craiova Maxima ajunge în semifinalele Cupei UEFA, unde Benfica trece mai departe doar prin regula golurilor din deplasare. În același an, Știința câștigă din nou Cupa României.', true ),
			array( '1991', 'Al patrulea titlu, al doilea event', 'Campionat și Cupa României: al doilea event din istoria clubului.', true ),
			array( '1993', 'Cupa României', 'Un nou trofeu de Cupă pentru alb-albaștri.', true ),
		),
		'Renașterea' => array(
			array( '2013', 'Un nou început', 'Proiectul fotbalistic CS Universitatea Craiova este relansat.', false ),
			array( '2014', 'Înapoi în Liga I', 'Știința promovează și revine în prima ligă.', false ),
			array( '2017', 'Noul „Ion Oblemenco”', 'Este inaugurat noul stadion Ion Oblemenco, cu aproape 31.000 de locuri: casa modernă a Științei, care poartă numele celui mai iubit golgheter al ei.', false ),
			array( '2018', 'Cupa României', 'Primul trofeu al noii ere.', true ),
			array( '2021', 'Cupa și Supercupa', 'Universitatea Craiova câștigă Cupa României și Supercupa României.', true ),
			array( '2026', 'Campioana, Cupa și Supercupa', 'Un an istoric: Știința câștigă Cupa României, apoi titlul de campioană, primul după 35 de ani, și încheie cu Supercupa României. Trei trofee într-un singur an.', true ),
		),
	);
}

add_shortcode( 'ps_istorie', 'ps_child_istorie_shortcode' );
function ps_child_istorie_shortcode() {
	$e   = 'esc_html';
	$img = get_stylesheet_directory_uri() . '/assets/istorie/';
	ob_start();
	?>
	<div class="ps-ist">
		<section class="ps-ist-hero">
			<span class="ps-ist-ani">1948 – 2026</span>
			<h1>Repere istorice</h1>
			<p class="ps-ist-sub">Leii din Bănie · Alb-albaștrii · Campioana unei mari iubiri</p>
			<p class="ps-ist-intro">Istoria Universității Craiova este una dintre cele mai frumoase povești ale fotbalului românesc. De la echipa studenților din 1948 până la legendara Craiova Maxima și la tripla din 2026, Știința a devenit un simbol al Olteniei.</p>
		</section>

		<section class="ps-ist-palmares">
			<div><b>5</b><span>titluri de campioană</span><small>1974 · 1980 · 1981 · 1991 · 2026</small></div>
			<div><b>9</b><span>Cupe ale României</span><small>1977 · 1978 · 1981 · 1983 · 1991 · 1993 · 2018 · 2021 · 2026</small></div>
			<div><b>2</b><span>Supercupe ale României</span><small>2021 · 2026</small></div>
			<div><b>1983</b><span>semifinala Cupei UEFA</span><small>Craiova Maxima</small></div>
		</section>

		<section class="ps-ist-timeline">
			<?php foreach ( ps_child_istorie_data() as $era => $items ) : ?>
				<h2 class="ps-ist-era"><span><?php echo $e( $era ); ?></span></h2>
				<?php foreach ( $items as $i => $it ) : ?>
					<article class="ps-ist-item<?php echo $it[3] ? ' ps-ist-trofeu' : ''; ?>">
						<span class="ps-ist-an"><?php echo $e( $it[0] ); ?></span>
						<?php if ( $it[3] ) : ?><span class="ps-ist-badge">Trofeu</span><?php endif; ?>
						<h3><?php echo $e( $it[1] ); ?></h3>
						<p><?php echo $e( $it[2] ); ?></p>
					</article>
				<?php endforeach; ?>
			<?php endforeach; ?>
		</section>

		<section class="ps-ist-2026">
			<span class="ps-ist-ani">2026</span>
			<h2>Știința, din nou regina României</h2>
			<p>După 35 de ani, titlul revine în Bănie. Un nou event și Supercupa încununează un sezon istoric.</p>
			<ul>
				<li><b>13 mai 2026</b> Cupa României, după finala cu Universitatea Cluj: 0–0, 6–5 la loviturile de departajare.</li>
				<li><b>17 mai 2026</b> Campioana României, după 5–0 cu U Cluj pe „Ion Oblemenco”. Al treilea event din istoria clubului.</li>
				<li><b>12 iulie 2026</b> Supercupa României, după 1–1 și 5–3 la loviturile de departajare cu Universitatea Cluj.</li>
			</ul>
		</section>

		<section class="ps-ist-maxima">
			<figure class="ps-ist-foto">
				<img src="<?php echo esc_url( $img . 'stadion-vechi.jpg' ); ?>" alt="Vechiul stadion din Craiova, în nocturnă" loading="lazy" width="800" height="602">
				<figcaption>Vechiul stadion din Craiova, scena marilor nopți europene ale Științei. A fost demolat în 2015, iar pe locul lui s-a ridicat noul „Ion Oblemenco”.</figcaption>
			</figure>
			<h2>Craiova Maxima – apogeul Științei</h2>
			<p>Perioada 1980–1983 reprezintă vârful performanțelor europene ale Universității Craiova: prima echipă românească ajunsă într-o semifinală europeană.</p>
			<ul>
				<li><b>1979</b> Universitatea elimină Leeds United din Cupa UEFA: 2–0 și 2–0.</li>
				<li><b>1982</b> Sferturi în Cupa Campionilor Europeni, cu Bayern München (1–3 la general).</li>
				<li><b>1982–1983</b> Drumul spre semifinala Cupei UEFA trece pe la Fiorentina și Bordeaux.</li>
				<li><b>16 martie 1983</b> Universitatea – Kaiserslautern 1–0, gol Nicolae Negrilă. Calificare în semifinalele Cupei UEFA.</li>
				<li><b>6 aprilie 1983</b> Benfica – Universitatea 0–0.</li>
				<li><b>20 aprilie 1983</b> Universitatea – Benfica 1–1. Știința iese din cursă doar prin regula golurilor marcate în deplasare.</li>
			</ul>
			<p class="ps-ist-nota">Pe banca Craiovei Maxima s-au aflat Constantin Oțet, Valentin Stănescu, Ion Oblemenco și Nicolae Ivan.</p>
		</section>

		<section class="ps-ist-legende">
			<h2>Legendele Științei</h2>
			<div class="ps-ist-cards">
				<div><b>Ion Oblemenco</b><span>Simbolul Științei, marele ei golgheter și apoi antrenor. Stadionul din Craiova îi poartă numele.</span></div>
				<div class="ps-ist-cu-foto"><img src="<?php echo esc_url( $img . 'ilie-balaci.jpg' ); ?>" alt="Ilie Balaci" loading="lazy"><b>Ilie Balaci</b><span>„Minunea Blondă”, geniul Craiovei Maxima.</span></div>
				<div><b>Costică Ștefănescu</b><span>Căpitanul generației europene de aur, cu 490 de meciuri în prima ligă.</span></div>
			</div>
			<p>Au mai scris istorie: Sorin Cârțu, Rodion Cămătaru, Nicolae Negrilă, Aurel Țicleanu, Ștefan Sameș, Zoltán Crișan, Gheorghe Craioveanu, Pavel Badea și Gică Popescu.</p>
		</section>

		<section class="ps-ist-steme">
			<h2>Stemele Științei</h2>
			<p>De-a lungul anilor, Știința a purtat mai multe steme, dar culorile au rămas mereu aceleași: albul și albastrul.</p>
			<div class="ps-ist-steme-grid">
				<figure><img src="<?php echo esc_url( $img . 'stema-u.png' ); ?>" alt="Stema Universității Craiova cu litera U" loading="lazy"><figcaption>Sigla cu „U”-ul studenților</figcaption></figure>
				<figure><img src="<?php echo esc_url( $img . 'stema-scut.png' ); ?>" alt="Stema Universității Craiova în dungi alb-albastre" loading="lazy"><figcaption>Sigla în dungi alb-albastre</figcaption></figure>
				<figure><img src="<?php echo esc_url( $img . 'stema-fanion.png' ); ?>" alt="Stema Universității Craiova din anii '80, în formă de fanion" loading="lazy"><figcaption>Fanionul anilor '80</figcaption></figure>
				<figure><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/club/stema-craiova.png' ); ?>" alt="Stema actuală a Universității Craiova, cu leul și litera U" loading="lazy"><figcaption>Stema de azi</figcaption></figure>
			</div>
		</section>

		<p class="ps-ist-credit">Imagini: Wikipedia și Wikimedia Commons.</p>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Lotul: câmpurile fișei de jucător, importul automat și pagina jucătorului (single-team.php).
 */
const PS_JUCATOR_CAMPURI = array(
	'ps_nationalitate' => 'Naționalitate',
	'ps_data_nasterii' => 'Data nașterii (AAAA-LL-ZZ)',
	'ps_inaltime'      => 'Înălțime (cm)',
	'ps_greutate'      => 'Greutate (kg)',
	'ps_picior'        => 'Picior preferat',
);
const PS_STAFF_CATEGORII = array( 'staff-tehnic', 'conducere' );
const PS_POSTURI = array(
	'Portar'   => array( 'Portari', 1 ),
	'Fundaș'   => array( 'Fundași', 2 ),
	'Mijlocaș' => array( 'Mijlocași', 3 ),
	'Atacant'  => array( 'Atacanți', 4 ),
);

// ordinea din carusel se alege din „Atribute pagină”
add_action( 'init', function () {
	add_post_type_support( 'team', 'page-attributes' );
}, 20 );

add_action( 'add_meta_boxes_team', function () {
	add_meta_box( 'ps-jucator', 'Fișa jucătorului', 'ps_child_jucator_metabox', 'team', 'side' );
} );

function ps_child_jucator_metabox( $post ) {
	wp_nonce_field( 'ps_jucator', 'ps_jucator_nonce' );
	foreach ( PS_JUCATOR_CAMPURI as $key => $label ) {
		printf(
			'<p><label for="%1$s">%2$s</label><br><input type="text" class="widefat" id="%1$s" name="%1$s" value="%3$s"></p>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( get_post_meta( $post->ID, $key, true ) )
		);
	}
	echo '<p class="description">Vârsta se calculează singură din data nașterii.</p>';
}

add_action( 'save_post_team', function ( $id ) {
	if ( ! isset( $_POST['ps_jucator_nonce'] ) || ! wp_verify_nonce( $_POST['ps_jucator_nonce'], 'ps_jucator' ) || ! current_user_can( 'edit_post', $id ) ) {
		return;
	}
	foreach ( array_keys( PS_JUCATOR_CAMPURI ) as $key ) {
		if ( isset( $_POST[ $key ] ) ) {
			update_post_meta( $id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
} );

function ps_child_varsta( $data ) {
	$nastere = date_create( $data );
	return $nastere ? $nastere->diff( date_create( 'today', wp_timezone() ) )->y : '';
}

// În liste (carusel, pagina „Echipa”) apar doar jucătorii care au poză; fișele există pentru toți.
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || $q->is_singular() || $q->get( 'ps_toti' ) || 'team' !== $q->get( 'post_type' ) ) {
		return;
	}
	$meta   = (array) $q->get( 'meta_query' );
	$meta[] = array( 'key' => '_thumbnail_id', 'compare' => 'EXISTS' );
	$q->set( 'meta_query', $meta );
	if ( ! $q->get( 'tax_query' ) ) {
		$q->set( 'tax_query', array( array( 'taxonomy' => 'team-category', 'field' => 'slug', 'terms' => PS_STAFF_CATEGORII, 'operator' => 'NOT IN' ) ) );
	}
} );

/**
 * Import lot: POST /ps/v1/jucatori { jucatori: [ {nume, numar, post, data_nasterii, tara, inaltime, greutate, picior,
 * imagine_id?, video_id?, biografie?} ] }. Jucătorul existent (după nume) se actualizează, altfel se creează.
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'ps/v1', '/jucatori', array(
		array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => 'ps_child_jucatori_lista',
		),
		array(
			'methods'             => 'POST',
			'permission_callback' => function () { return current_user_can( 'edit_others_posts' ); },
			'callback'            => 'ps_child_jucatori_import',
		),
	) );
} );

function ps_child_jucator_cheie( $nume ) {
	return sanitize_title( remove_accents( $nume ) );
}

function ps_child_jucatori_lista() {
	$out = array();
	foreach ( get_posts( array( 'post_type' => 'team', 'post_status' => 'any', 'numberposts' => -1, 'ps_toti' => true ) ) as $p ) {
		$out[] = array(
			'id'     => $p->ID,
			'nume'   => $p->post_title,
			'status' => $p->post_status,
			'numar'  => function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( $p->ID, 'num' ) : '',
			'poza'   => has_post_thumbnail( $p ),
			'video'  => function_exists( 'fw_get_db_post_option' ) ? ! empty( fw_get_db_post_option( $p->ID, 'hover-video' )['url'] ) : false,
			'bio'    => '' !== trim( $p->post_content ),
			'elementor' => ps_child_jucator_are_elementor( $p->ID ),
		);
	}
	return $out;
}

function ps_child_jucatori_import( WP_REST_Request $req ) {
	if ( ! function_exists( 'fw_set_db_post_option' ) ) {
		return new WP_Error( 'ps_fw', 'Lipsește LT Core (Unyson).', array( 'status' => 500 ) );
	}
	$existenti = array();
	foreach ( get_posts( array( 'post_type' => 'team', 'post_status' => 'any', 'numberposts' => -1, 'ps_toti' => true ) ) as $p ) {
		$existenti[ ps_child_jucator_cheie( $p->post_title ) ] = $p->ID;
	}
	$rezultat = array();
	foreach ( (array) $req->get_param( 'jucatori' ) as $j ) {
		$nume = sanitize_text_field( $j['nume'] ?? '' );
		if ( '' === $nume ) {
			continue;
		}
		$post  = $j['post'] ?? '';
		$ord   = PS_POSTURI[ $post ][1] ?? 5;
		$cheie = ps_child_jucator_cheie( $nume );
		$data  = array(
			'post_type'   => 'team',
			'post_title'  => $nume,
			'post_status' => in_array( $j['status'] ?? '', array( 'draft', 'publish' ), true ) ? $j['status'] : 'publish',
			'menu_order'  => isset( $j['ordine'] ) ? (int) $j['ordine'] : $ord * 100 + (int) ( $j['numar'] ?? 99 ),
		);
		// biografia: doar dacă jucătorul nu are deja una (sau dacă se cere explicit suprascrierea)
		if ( ! empty( $j['biografie'] ) && ( ! isset( $existenti[ $cheie ] ) || ! empty( $j['suprascrie_bio'] ) || '' === trim( get_post_field( 'post_content', $existenti[ $cheie ] ) ) ) ) {
			$data['post_content'] = wp_kses_post( $j['biografie'] );
		}
		if ( isset( $existenti[ $cheie ] ) ) {
			$data['ID'] = $existenti[ $cheie ];
			$id         = wp_update_post( $data, true );
			$actiune    = 'actualizat';
		} else {
			$id      = wp_insert_post( $data, true );
			$actiune = 'creat';
		}
		if ( is_wp_error( $id ) ) {
			$rezultat[] = array( 'nume' => $nume, 'eroare' => $id->get_error_message() );
			continue;
		}

		fw_set_db_post_option( $id, 'num', (string) ( $j['numar'] ?? '' ) );
		fw_set_db_post_option( $id, 'subheader', $post );
		if ( ! empty( $j['data_nasterii'] ) ) {
			fw_set_db_post_option( $id, 'age', (string) ps_child_varsta( $j['data_nasterii'] ) );
		}
		$meta = array(
			'ps_nationalitate' => $j['tara'] ?? '',
			'ps_data_nasterii' => $j['data_nasterii'] ?? '',
			'ps_inaltime'      => $j['inaltime'] ?? '',
			'ps_greutate'      => $j['greutate'] ?? '',
			'ps_picior'        => $j['picior'] ?? '',
		);
		foreach ( $meta as $k => $v ) {
			if ( '' !== (string) $v ) {
				update_post_meta( $id, $k, sanitize_text_field( (string) $v ) );
			}
		}
		$categorie = PS_POSTURI[ $post ][0] ?? ( $j['categorie'] ?? '' );
		if ( $categorie ) {
			$term = term_exists( $categorie, 'team-category' ) ?: wp_insert_term( $categorie, 'team-category' );
			if ( ! is_wp_error( $term ) ) {
				wp_set_object_terms( $id, (int) $term['term_id'], 'team-category' );
			}
		}
		if ( ! empty( $j['imagine_id'] ) ) {
			set_post_thumbnail( $id, (int) $j['imagine_id'] );
		}
		if ( ! empty( $j['video_id'] ) && ( $url = wp_get_attachment_url( (int) $j['video_id'] ) ) ) {
			fw_set_db_post_option( $id, 'hover-video', array( 'attachment_id' => (int) $j['video_id'], 'url' => $url ) );
		}
		$rezultat[] = array( 'nume' => $nume, 'id' => $id, 'actiune' => $actiune );
	}
	return $rezultat;
}

/**
 * Pagina din Elementor contează doar dacă are widgeturi; deschiderea editorului pe un jucător lasă în urmă o pagină goală.
 */
function ps_child_jucator_are_elementor( $id ) {
	if ( 'builder' !== get_post_meta( $id, '_elementor_edit_mode', true ) ) {
		return false;
	}
	return false !== strpos( (string) get_post_meta( $id, '_elementor_data', true ), '"widgetType"' );
}

/**
 * Fișa jucătorului (single-team.php): date, biografie (conținutul articolului) și clipul care rulează o dată.
 */
function ps_child_jucator_fisa( $id ) {
	$luni  = array( 'ianuarie', 'februarie', 'martie', 'aprilie', 'mai', 'iunie', 'iulie', 'august', 'septembrie', 'octombrie', 'noiembrie', 'decembrie' );
	$fw    = function_exists( 'fw_get_db_post_option' );
	$num   = $fw ? fw_get_db_post_option( $id, 'num' ) : '';
	$post  = $fw ? fw_get_db_post_option( $id, 'subheader' ) : '';
	$video = $fw ? ( fw_get_db_post_option( $id, 'hover-video' )['url'] ?? '' ) : '';
	$soc   = $fw ? (array) fw_get_db_post_option( $id, 'items' ) : array();
	$nast  = get_post_meta( $id, 'ps_data_nasterii', true );
	$d     = $nast ? date_create( $nast ) : false;

	$e_staff = has_term( PS_STAFF_CATEGORII, 'team-category', $id );
	$date    = array(
		( $e_staff ? 'Funcție' : 'Post' ) => $post,
		'Naționalitate' => get_post_meta( $id, 'ps_nationalitate', true ),
		'Data nașterii' => $d ? (int) $d->format( 'j' ) . ' ' . $luni[ $d->format( 'n' ) - 1 ] . ' ' . $d->format( 'Y' ) : '',
		'Vârstă'        => $nast ? ps_child_varsta( $nast ) . ' ani' : ( $fw ? fw_get_db_post_option( $id, 'age' ) : '' ),
		'Înălțime'      => ( $h = get_post_meta( $id, 'ps_inaltime', true ) ) ? $h . ' cm' : '',
		'Greutate'      => ( $g = get_post_meta( $id, 'ps_greutate', true ) ) ? $g . ' kg' : '',
		'Picior'        => get_post_meta( $id, 'ps_picior', true ),
	);
	$poza = get_the_post_thumbnail_url( $id, 'full' );
	$echipa = get_page_by_path( 'echipa' );
	ob_start();
	?>
	<div class="ps-jucator">
		<div class="ps-jucator-info">
			<div class="ps-jucator-cap">
				<?php if ( '' !== (string) $num ) : ?>
					<div class="ps-jucator-tricou" aria-label="Numărul <?php echo esc_attr( $num ); ?>">
						<svg viewBox="0 0 100 90" aria-hidden="true"><path d="M30 4 L12 12 L0 32 L16 42 L22 34 L22 88 L78 88 L78 34 L84 42 L100 32 L88 12 L70 4 Q50 18 30 4 Z"/></svg>
						<span><?php echo esc_html( $num ); ?></span>
					</div>
				<?php endif; ?>
				<h2><?php echo esc_html( get_the_title( $id ) ); ?></h2>
			</div>
			<dl class="ps-jucator-date">
				<?php foreach ( $date as $eticheta => $valoare ) : if ( '' === (string) $valoare ) continue; ?>
					<div><dt><?php echo esc_html( $eticheta ); ?>:</dt><dd><?php echo esc_html( $valoare ); ?></dd></div>
				<?php endforeach; ?>
			</dl>
			<?php $bio = trim( get_post_field( 'post_content', $id ) ); if ( '' !== $bio ) : ?>
				<h3>Biografie</h3>
				<div class="ps-jucator-bio"><?php echo apply_filters( 'the_content', $bio ); ?></div>
			<?php endif; ?>
			<?php if ( $soc ) : ?>
				<ul class="ps-jucator-social">
					<?php foreach ( $soc as $s ) : if ( empty( $s['href'] ) || '#' === $s['href'] ) continue; ?>
						<li><a href="<?php echo esc_url( $s['href'] ); ?>" target="_blank" rel="noopener"><?php if ( ! empty( $s['icon']['icon-class'] ) ) : ?><span class="<?php echo esc_attr( $s['icon']['icon-class'] ); ?>"></span> <?php endif; echo esc_html( $s['header'] ?? '' ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<?php if ( $echipa ) : ?>
				<a class="lte-btn btn-main ps-jucator-inapoi" href="<?php echo esc_url( get_permalink( $echipa ) ); ?>">Toată echipa</a>
			<?php endif; ?>
		</div>
		<div class="ps-jucator-media">
			<?php if ( $video ) : ?>
				<video class="ps-jucator-video" src="<?php echo esc_url( $video ); ?>" poster="<?php echo esc_url( $poza ); ?>" muted playsinline autoplay preload="auto" aria-label="<?php echo esc_attr( get_the_title( $id ) ); ?>"></video>
				<script>(function(v){if(window.matchMedia('(prefers-reduced-motion: reduce)').matches){v.removeAttribute('autoplay');v.pause();}})(document.currentScript.previousElementSibling);</script>
			<?php elseif ( $poza ) : ?>
				<img src="<?php echo esc_url( $poza ); ?>" alt="<?php echo esc_attr( get_the_title( $id ) ); ?>">
			<?php endif; ?>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * [ps_staff categorie="Staff tehnic"] – staff-ul tehnic sau conducerea, din membrii echipei din categoria respectivă.
 */
add_shortcode( 'ps_staff', 'ps_child_staff_shortcode' );
function ps_child_staff_shortcode( $atts ) {
	$a    = shortcode_atts( array( 'categorie' => 'Staff tehnic', 'functie' => '' ), $atts );
	$term = get_term_by( 'name', $a['categorie'], 'team-category' );
	if ( ! $term ) {
		return '';
	}
	$oameni = get_posts( array(
		'post_type'   => 'team',
		'numberposts' => -1,
		'orderby'     => 'menu_order',
		'order'       => 'ASC',
		'ps_toti'     => true,
		'tax_query'   => array( array( 'taxonomy' => 'team-category', 'field' => 'term_id', 'terms' => $term->term_id ) ),
	) );
	if ( ! $oameni ) {
		return '';
	}
	$luni = array( 'ianuarie', 'februarie', 'martie', 'aprilie', 'mai', 'iunie', 'iulie', 'august', 'septembrie', 'octombrie', 'noiembrie', 'decembrie' );
	ob_start();
	echo '<div class="ps-staff">';
	foreach ( $oameni as $o ) {
		$functie = function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( $o->ID, 'subheader' ) : '';
		if ( $a['functie'] && false === mb_stripos( (string) $functie, $a['functie'] ) ) {
			continue;
		}
		$detalii = array_filter( array( get_post_meta( $o->ID, 'ps_nationalitate', true ) ) );
		if ( ( $n = get_post_meta( $o->ID, 'ps_data_nasterii', true ) ) && ( $d = date_create( $n ) ) ) {
			$detalii[] = 'născut în ' . $d->format( 'Y' );
		}
		echo '<div class="ps-staff-card">';
		if ( has_post_thumbnail( $o ) ) {
			echo get_the_post_thumbnail( $o, 'thumbnail', array( 'class' => 'ps-staff-foto' ) );
		}
		printf( '<span class="ps-staff-functie">%s</span><b>%s</b>', esc_html( $functie ), esc_html( $o->post_title ) );
		if ( $detalii ) {
			printf( '<small>%s</small>', esc_html( implode( ' · ', $detalii ) ) );
		}
		echo '</div>';
	}
	echo '</div>';
	return ob_get_clean();
}

/**
 * Pagina meciului: marcatorii (din cronică), rezumatul de sus ca în tema demo, apoi cronica și rezumatul video.
 */
function ps_child_set_marcatori( $match_id, $marcatori ) {
	$curat = array();
	foreach ( array( 'gazde', 'oaspeti' ) as $parte ) {
		$curat[ $parte ] = array();
		foreach ( (array) ( $marcatori[ $parte ] ?? array() ) as $m ) {
			if ( ! empty( $m['nume'] ) ) {
				$curat[ $parte ][] = array( 'nume' => sanitize_text_field( $m['nume'] ), 'minut' => sanitize_text_field( $m['minut'] ?? '' ) );
			}
		}
	}
	update_post_meta( $match_id, '_ps_marcatori', $curat );
}

function ps_child_set_statistici( $match_id, $randuri, $sursa = 'LPF' ) {
	$curat = array();
	foreach ( (array) $randuri as $r ) {
		if ( is_array( $r ) && 3 === count( $r ) ) {
			$curat[] = array_map( 'sanitize_text_field', array_map( 'strval', array_values( $r ) ) );
		}
	}
	update_post_meta( $match_id, '_ps_statistici', $curat );
	update_post_meta( $match_id, '_ps_statistici_sursa', sanitize_text_field( $sursa ) );
}

// POST /ps/v1/marcatori [ { data, gazde?: [{nume, minut}], oaspeti?: [...], statistici?: [[titlu, gazde, oaspeți]] } ] – completează meciurile jucate.
add_action( 'rest_api_init', function () {
	register_rest_route( 'ps/v1', '/marcatori', array(
		'methods'             => 'POST',
		'permission_callback' => function () { return current_user_can( 'edit_others_posts' ); },
		'callback'            => function ( WP_REST_Request $req ) {
			$out = array();
			foreach ( (array) $req->get_json_params() as $m ) {
				$id = ps_child_meci_din_data( $m['data'] ?? '' );
				if ( $id && ( isset( $m['gazde'] ) || isset( $m['oaspeti'] ) ) ) {
					ps_child_set_marcatori( $id, $m );
				}
				if ( $id && ! empty( $m['statistici'] ) ) {
					ps_child_set_statistici( $id, $m['statistici'], $m['sursa_statistici'] ?? 'LPF' );
				}
				$out[] = array( 'data' => $m['data'] ?? '', 'meci' => $id );
			}
			return $out;
		},
	) );
} );

function ps_child_meci_din_data( $date ) {
	$ts = strtotime( $date );
	if ( ! $ts ) {
		return 0;
	}
	$posts = get_posts( array(
		'post_type'   => 'lte-football',
		'post_status' => array( 'publish', 'future' ),
		'numberposts' => 1,
		'fields'      => 'ids',
		'date_query'  => array( array( 'year' => gmdate( 'Y', $ts ), 'month' => gmdate( 'n', $ts ), 'day' => gmdate( 'j', $ts ) ) ),
	) );
	return $posts ? (int) $posts[0] : 0;
}

/**
 * Cronica și rezumatul video publicate pentru meciul din ziua respectivă (după id-ul din depozit: „AAAA-LL-ZZ-…”).
 */
function ps_child_meci_articole( $match_id ) {
	$zi  = get_the_date( 'Y-m-d', $match_id );
	$out = array( 'cronica' => null, 'video' => null );
	$ids = get_posts( array(
		'post_type'   => 'post',
		'post_status' => 'publish',
		'numberposts' => 10,
		'meta_query'  => array( array( 'key' => '_ps_sursa', 'value' => $zi . '-', 'compare' => 'LIKE' ) ),
	) );
	foreach ( $ids as $p ) {
		$sursa = (string) get_post_meta( $p->ID, '_ps_sursa', true );
		if ( 0 !== strpos( $sursa, $zi . '-' ) || false !== strpos( $sursa, '-florin-' ) || false !== strpos( $sursa, '-george-' ) ) {
			continue;
		}
		$cheie = '-video' === substr( $sursa, -6 ) ? 'video' : 'cronica';
		if ( ! $out[ $cheie ] ) {
			$out[ $cheie ] = $p;
		}
	}
	return $out;
}

function ps_child_meci_pagina( $match_id ) {
	$marcatori = get_post_meta( $match_id, '_ps_marcatori', true );
	$marcatori = is_array( $marcatori ) ? $marcatori : array();
	$randuri   = function ( $parte ) use ( $marcatori ) {
		$r = array();
		foreach ( (array) ( $marcatori[ $parte ] ?? array() ) as $m ) {
			$r[] = array( 'name' => $m['nume'], 'timing' => $m['minut'] );
		}
		return $r;
	};
	$art = ps_child_meci_articole( $match_id );
	ob_start();
	echo '<div class="ps-meci">';
	if ( function_exists( 'lte_sc_output' ) ) {
		$teren = ps_child_teren_id();
		lte_sc_output( 'football-summary', array(
			'list'       => $randuri( 'gazde' ),
			'list-right' => $randuri( 'oaspeti' ),
			'image'      => $teren ? array( 'id' => $teren ) : array(),
		) );
	}
	echo ps_child_meci_statistici( $match_id ); // phpcs:ignore -- escapat în funcție
	echo '<div class="ps-meci-continut">';
	if ( $art['video'] ) {
		$url = trim( wp_strip_all_tags( $art['video']->post_content ) );
		$emb = $url ? wp_oembed_get( $url ) : '';
		if ( $emb ) {
			echo '<section class="ps-meci-video"><h2>Rezumatul meciului</h2><div class="ps-meci-embed">' . $emb . '</div></section>'; // phpcs:ignore -- HTML oEmbed de la YouTube
		}
	}
	if ( $art['cronica'] ) {
		$c = $art['cronica'];
		echo '<article class="ps-meci-cronica">';
		echo '<span class="ps-meci-eticheta">Cronica meciului</span>';
		printf( '<h2><a href="%s">%s</a></h2>', esc_url( get_permalink( $c ) ), esc_html( get_the_title( $c ) ) );
		if ( has_post_thumbnail( $c ) ) {
			echo get_the_post_thumbnail( $c, 'full', array( 'class' => 'ps-meci-coperta' ) );
		}
		echo ps_child_semnatura( $c ); // phpcs:ignore -- escapat în funcție
		echo '<div class="ps-meci-text">' . ps_child_legaturi_interne( apply_filters( 'the_content', $c->post_content ) ) . '</div>'; // phpcs:ignore -- conținutul articolului
		echo '</article>';
	} elseif ( get_post_time( 'U', true, $match_id ) < time() ) {
		echo '<p class="ps-meci-curand">Cronica meciului apare în curând.</p>';
	}
	echo '</div></div>';
	return ob_get_clean();
}

/**
 * Statisticile meciului (LPF): bara de posesie și tabelul temei („lte-match-stat”), gazdele în stânga.
 */
function ps_child_meci_statistici( $match_id ) {
	$randuri = get_post_meta( $match_id, '_ps_statistici', true );
	if ( ! is_array( $randuri ) || ! $randuri ) {
		return '';
	}
	$dupa = array();
	foreach ( $randuri as $r ) {
		$dupa[ $r[0] ] = $r;
	}
	$alese = array( 'Șuturi', 'Șuturi pe poartă', 'Atacuri', 'Total pase', 'Pase precise', 'Cornere', 'Ofsaiduri', 'Parade', 'Faulturi', 'Dueluri câștigate', 'Cartonașe galbene', 'Cartonașe roșii' );
	$fw    = function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( $match_id ) : array();
	$nume  = function ( $k ) use ( $fw ) {
		$t = ! empty( $fw[ $k ] ) ? get_term( (int) $fw[ $k ], 'lte-football-club' ) : null;
		return $t && ! is_wp_error( $t ) ? $t->name : '';
	};
	ob_start();
	echo '<section class="ps-meci-stat"><h2>Statistici</h2>';
	if ( isset( $dupa['Posesia mingii'] ) ) {
		$g = (int) $dupa['Posesia mingii'][1];
		$o = (int) $dupa['Posesia mingii'][2];
		printf(
			'<div class="ps-posesie"><div class="ps-posesie-cap"><b>%1$d%%</b><span>Posesia mingii</span><b>%2$d%%</b></div><div class="ps-posesie-bara"><i style="width:%1$d%%"></i><i style="width:%2$d%%"></i></div><div class="ps-posesie-echipe"><span>%3$s</span><span>%4$s</span></div></div>',
			$g, $o, esc_html( $nume( 'team-1' ) ), esc_html( $nume( 'team-2' ) )
		);
	}
	$list = array();
	foreach ( $alese as $titlu ) {
		if ( ! isset( $dupa[ $titlu ] ) ) {
			continue;
		}
		$icon   = 'Cartonașe galbene' === $titlu ? 'yellow' : ( 'Cartonașe roșii' === $titlu ? 'red' : '' );
		$list[] = array( 'title' => $titlu, 'left-score' => $dupa[ $titlu ][1], 'right-score' => $dupa[ $titlu ][2], 'left-icon' => $icon, 'right-icon' => $icon );
	}
	if ( $list && function_exists( 'lte_sc_output' ) ) {
		lte_sc_output( 'football-stat', array( 'list' => $list ) );
	}
	$surse = array( 'LPF' => 'Liga Profesionistă de Fotbal (lpf.ro)', 'UEFA' => 'UEFA (uefa.com)' );
	$sursa = (string) get_post_meta( $match_id, '_ps_statistici_sursa', true );
	printf( '<p class="ps-meci-sursa">Sursa statisticilor: %s</p></section>', esc_html( $surse[ $sursa ] ?? $surse['LPF'] ) );
	return ob_get_clean();
}

/**
 * Terenul de sub scor: imaginea „ps-teren.png” din Media (aceeași ca în tema demo), căutată o dată și ținută minte.
 */
function ps_child_teren_id() {
	$id = (int) get_option( 'ps_teren_id' );
	if ( $id && wp_attachment_is_image( $id ) ) {
		return $id;
	}
	$gasit = get_posts( array(
		'post_type'   => 'attachment',
		'post_status' => 'inherit',
		'numberposts' => 1,
		'fields'      => 'ids',
		'meta_query'  => array( array( 'key' => '_wp_attached_file', 'value' => 'ps-teren', 'compare' => 'LIKE' ) ),
	) );
	$id = $gasit ? (int) $gasit[0] : 0;
	update_option( 'ps_teren_id', $id, false );
	return $id;
}

/**
 * Semnătura autorului deasupra textului: „de George Fedorovici · 29 octombrie 2026”.
 */
function ps_child_semnatura( $post ) {
	$autor = get_the_author_meta( 'display_name', $post->post_author );
	if ( ! $autor ) {
		return '';
	}
	return sprintf(
		'<p class="ps-semnatura">de <a href="%s">%s</a> <span>· %s</span></p>',
		esc_url( get_author_posts_url( $post->post_author ) ),
		esc_html( $autor ),
		esc_html( get_the_date( 'j F Y', $post ) )
	);
}

add_filter( 'the_content', function ( $content ) {
	if ( is_singular( 'post' ) && in_the_loop() && is_main_query() ) {
		// Rând nou după semnătură: altfel linkul YouTube nu mai e singur pe rând și WordPress nu-l transformă în player.
		$content = ps_child_semnatura( get_post() ) . "\n\n" . $content;
	}
	return $content;
}, 5 );

/**
 * [ps_despre] – pagina „Despre club”, pe structura paginii About din tema demo: prezentare, palmares,
 * stadionul, citatul, banca tehnică și ce definește clubul.
 */
function ps_child_pagina_link( $slugs ) {
	foreach ( (array) $slugs as $slug ) {
		if ( $p = get_page_by_path( $slug ) ) {
			return get_permalink( $p );
		}
	}
	return '';
}

add_shortcode( 'ps_despre', 'ps_child_despre_shortcode' );
function ps_child_despre_shortcode() {
	$img     = get_stylesheet_directory_uri() . '/assets/';
	$echipa  = ps_child_pagina_link( array( 'echipa' ) );
	$istorie = ps_child_pagina_link( array( 'repere-istorice', 'istorie', 'istoria' ) );
	ob_start();
	?>
	<div class="ps-despre">
		<section class="ps-despre-intro">
			<div class="ps-despre-text">
				<span class="ps-despre-ochi">Despre club</span>
				<h2>Universitatea Craiova</h2>
				<p class="ps-despre-sub">Leii din Bănie · alb-albaștrii · campioana unei mari iubiri</p>
				<p>Născută în 1948 ca echipă a studenților, Știința a devenit în câteva decenii mândria Olteniei. A urcat în prima ligă în 1964, a cucerit primul titlu în 1974, iar la începutul anilor '80 a scris, cu Craiova Maxima, cea mai frumoasă pagină europeană a unui club românesc: semifinala Cupei UEFA din 1983.</p>
				<p>Astăzi joacă pe „Ion Oblemenco”, una dintre cele mai moderne arene din țară, și a readus în 2026 titlul în Bănie, după 35 de ani, împreună cu Cupa și Supercupa României.</p>
				<div class="ps-despre-butoane">
					<?php if ( $echipa ) : ?><a class="lte-btn btn-main" href="<?php echo esc_url( $echipa ); ?>">Lotul și staff-ul</a><?php endif; ?>
					<?php if ( $istorie ) : ?><a class="lte-btn btn-second" href="<?php echo esc_url( $istorie ); ?>">Repere istorice</a><?php endif; ?>
				</div>
			</div>
			<div class="ps-despre-stema"><img src="<?php echo esc_url( $img . 'club/stema-craiova.png' ); ?>" alt="Stema Universității Craiova" loading="lazy"></div>
		</section>

		<section class="ps-despre-palmares">
			<div><b>1974 · 1980 · 1981 · 1991 · 2026</b><span>campioană a României</span></div>
			<div><b>9 trofee</b><span>Cupa României</span></div>
			<div><b>2021 · 2026</b><span>Supercupa României</span></div>
			<div><b>1983</b><span>semifinală în Cupa UEFA</span></div>
		</section>

		<section class="ps-despre-stadion">
			<figure>
				<img src="<?php echo esc_url( $img . 'club/stadion-oblemenco.jpg' ); ?>" alt="Stadionul Ion Oblemenco din Craiova, văzut de sus" loading="lazy">
				<figcaption>Imagine: Google Earth</figcaption>
			</figure>
			<div class="ps-despre-stadion-text">
				<span class="ps-despre-ochi">Casa Științei</span>
				<h2>Stadionul „Ion Oblemenco”</h2>
				<p>Inaugurată în 2017 pe locul vechiului stadion, arena poartă numele celui mai iubit golgheter al Craiovei. Acoperișul alb, care îmbracă toată tribuna, se vede de departe în oraș, iar în serile de meci ovalul se umple de alb și albastru.</p>
				<ul>
					<li><b>30.983</b><span>locuri</span></li>
					<li><b>2017</b><span>inaugurat</span></li>
					<li><b>B-dul Ilie Balaci 8</b><span>Craiova</span></li>
				</ul>
			</div>
		</section>

		<blockquote class="ps-despre-citat">
			<p>„Campioana unei mari iubiri”</p>
			<cite>Adrian Păunescu, numele dat Științei după titlul din 1974</cite>
		</blockquote>

		<section class="ps-despre-banca">
			<span class="ps-despre-ochi">Banca tehnică</span>
			<h2>Antrenorii Științei</h2>
			<?php echo do_shortcode( '[ps_staff categorie="Staff tehnic" functie="Antrenor"]' ); ?>
		</section>

		<section class="ps-despre-valori">
			<span class="ps-despre-ochi">Ce ne definește</span>
			<h2>Mai mult decât un club</h2>
			<div class="ps-despre-carduri">
				<div><b>Tradiție</b><span>Din 1948, generații întregi au crescut cu Știința: de la Oblemenco la Craiova Maxima și la campionii din 2026.</span></div>
				<div><b>Academie</b><span>Centrul de Copii și Juniori pregătește următoarele generații. Baiaram și Screciu au crescut aici.</span></div>
				<div><b>Europa</b><span>Prima echipă românească într-o semifinală europeană, în 1983, și din nou în faza principală a unei cupe europene în 2026.</span></div>
				<div><b>Suporterii</b><span>Alb-albastrul se poartă în toată Oltenia și peste tot unde joacă Știința. Acest site e făcut de ei, pentru ei.</span></div>
			</div>
		</section>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Paginile cu articole pe sablonul Blog al temei (două coloane, bară laterală), fiecare cu categoriile ei.
 */
const PS_PAGINI_BLOG = array(
	'povestile-lui-florin' => array( 'Poveștile lui Florin', 'povestile-lui-florin' ),
	'penalty-cu-george'    => array( 'Penalty cu George', 'penalty-cu-george' ),
	'cronici'              => array( 'Cronici meciuri', 'superliga,cupa-romaniei,supercupa-romaniei,liga-campionilor,europa-league,conference-league' ),
	'stiri'                => array( 'Știri', 'stiri' ),
);

add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || $q->is_main_query() || 'post' !== $q->get( 'post_type' ) || $q->get( 's' ) || ! is_page_template( 'page-templates/blog.php' ) ) {
		return;
	}
	foreach ( PS_PAGINI_BLOG as $slug => $p ) {
		if ( is_page( $slug ) ) {
			$q->set( 'category_name', $p[1] );
			return;
		}
	}
} );

// POST /ps/v1/pagini-blog – creează paginile care lipsesc și le pune pe două coloane, cu bara în dreapta.
add_action( 'rest_api_init', function () {
	register_rest_route( 'ps/v1', '/pagini-blog', array(
		'methods'             => 'POST',
		'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		'callback'            => function () {
			$out = array();
			foreach ( PS_PAGINI_BLOG as $slug => $p ) {
				$pagina = get_page_by_path( $slug );
				$id     = $pagina ? $pagina->ID : wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $p[0], 'post_name' => $slug ) );
				if ( is_wp_error( $id ) ) {
					$out[ $slug ] = $id->get_error_message();
					continue;
				}
				update_post_meta( $id, '_wp_page_template', 'page-templates/blog.php' );
				if ( function_exists( 'fw_set_db_post_option' ) ) {
					fw_set_db_post_option( $id, 'blog-layout', 'two-cols' );
					fw_set_db_post_option( $id, 'sidebar-layout', 'right' );
				}
				$out[ $slug ] = array( 'id' => $id, 'url' => get_permalink( $id ), 'nou' => ! $pagina );
			}
			return $out;
		},
	) );
} );

/**
 * Legături interne în articole:
 * 1. href="ps:<id din depozit>" → articolul publicat cu acel id; href="ps:meci:AAAA-LL-ZZ" → pagina meciului.
 *    Dacă ținta nu e (încă) publicată, rămâne doar textul.
 * 2. Prima apariție a numelui complet al unui jucător sau om din staff („Prenume Nume” sau „Nume Prenume”)
 *    devine legătură spre lista articolelor care îl pomenesc („Articole despre …”). Nu se ating titlurile, legăturile existente și numele persoanei despre care e pagina.
 */
function ps_child_link_intern( $tinta ) {
	if ( 0 === strpos( $tinta, 'meci:' ) ) {
		$id = ps_child_meci_din_data( substr( $tinta, 5 ) );
		return $id ? get_permalink( $id ) : '';
	}
	$p = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => '_ps_sursa', 'meta_value' => $tinta ) );
	return $p ? get_permalink( $p[0] ) : '';
}

/* Porecle și alte forme ale numelor, după care oamenii din lot sunt recunoscuți în texte. */
function ps_child_porecle() {
	return array(
		'Laurențiu Popescu' => array( 'Popică' ),
		'Heri Tavares'      => array( 'Heriberto Tavares' ),
		'Assad Al Hamlawi'  => array( 'Assad', 'Al-Hamlawi' ),
	);
}

/* Expresie pentru un nume, indiferent de diacritice: „Stevanovic” găsește și „Stevanović”, „Joao” și „João”. */
function ps_child_re_nume( $nume ) {
	static $var = array(
		'a' => 'aăâáàãäå', 'c' => 'cćčç', 'd' => 'dđď', 'e' => 'eéèêëě', 'g' => 'gğ', 'i' => 'iîíìïı', 'l' => 'lł', 'n' => 'nñń',
		'o' => 'oóòôõöø', 'r' => 'rř', 's' => 'sșşšś', 't' => 'tțţť', 'u' => 'uúùûüů', 'y' => 'yý', 'z' => 'zžźż',
	);
	$re = '';
	foreach ( preg_split( '//u', remove_accents( $nume ), -1, PREG_SPLIT_NO_EMPTY ) as $ch ) {
		$mic = mb_strtolower( $ch );
		if ( isset( $var[ $mic ] ) ) {
			$cls = $ch === $mic ? $var[ $mic ] : mb_strtoupper( $var[ $mic ] );
			$re .= '[' . $cls . ']';
		} else {
			$re .= preg_quote( $ch, '/' );
		}
	}
	return '/(?<![\p{L}\p{M}])' . $re . '(?![\p{L}\p{M}])/u';
}

function ps_child_nume_oameni() {
	$cache = get_transient( 'ps_nume_complete4' );
	if ( is_array( $cache ) ) {
		return $cache;
	}
	$nume = array();
	foreach ( get_posts( array( 'post_type' => 'team', 'post_status' => 'publish', 'numberposts' => -1, 'ps_toti' => true ) ) as $o ) {
		$titlu = trim( preg_replace( '/\s+/', ' ', $o->post_title ) );
		$parti = explode( ' ', $titlu );
		if ( count( $parti ) < 2 ) {
			continue;
		}
		$invers = implode( ' ', array_slice( $parti, 1 ) ) . ' ' . $parti[0];
		$forme  = array_merge( array( $titlu, $invers ), ps_child_porecle()[ $titlu ] ?? array() );
		$nume[] = array( 'id' => $o->ID, 'url' => ps_child_url_articole_despre( $o ), 'forme' => array_values( array_unique( $forme ) ) );
	}
	set_transient( 'ps_nume_complete4', $nume, HOUR_IN_SECONDS );
	return $nume;
}
add_action( 'save_post_team', function () { delete_transient( 'ps_nume_complete4' ); } );

/**
 * „Articole despre <nume>”: căutarea temei, după numele complet (frază exactă), doar printre articole.
 */
function ps_child_url_articole_despre( $om ) {
	return add_query_arg( array( 's' => '"' . trim( $om->post_title ) . '"', 'om' => $om->ID ), home_url( '/' ) );
}

function ps_child_e_articole_despre() {
	return is_search() && ! empty( $_GET['om'] );
}

add_action( 'pre_get_posts', function ( $q ) {
	if ( ! is_admin() && $q->is_main_query() && $q->is_search() && ! empty( $_GET['om'] ) ) {
		$q->set( 'post_type', 'post' );
	}
} );

add_filter( 'get_search_query', function ( $q ) {
	return ps_child_e_articole_despre() ? trim( $q, '"' ) : $q;
} );

add_filter( 'gettext', function ( $tradus, $text, $domeniu ) {
	if ( 'atleticos' === $domeniu && 'Search Results: %s' === $text && ps_child_e_articole_despre() ) {
		return 'Articole despre %s';
	}
	return $tradus;
}, 10, 3 );

add_filter( 'document_title_parts', function ( $parti ) {
	if ( ps_child_e_articole_despre() ) {
		$parti['title'] = 'Articole despre ' . get_search_query();
	}
	return $parti;
} );

function ps_child_legaturi_interne( $html, $exclude_id = 0 ) {
	$html = preg_replace_callback( '/<a\s+href="ps:([^"]+)"\s*>(.*?)<\/a>/su', function ( $m ) {
		$url = ps_child_link_intern( $m[1] );
		return $url ? '<a href="' . esc_url( $url ) . '">' . $m[2] . '</a>' : $m[2];
	}, $html );

	$oameni = array_filter( ps_child_nume_oameni(), function ( $o ) use ( $exclude_id ) { return $o['id'] !== $exclude_id; } );
	// Jucătorii pe care articolul îi pomenește doar după numele de familie (ca la Florin): și acela devine legătură.
	$familie = array();
	foreach ( ps_child_jucatori_din_text( $html ) as $j ) {
		$familie[ $j['id'] ] = $j['alias'];
	}
	foreach ( $oameni as $k => $o ) {
		if ( isset( $familie[ $o['id'] ] ) ) {
			$oameni[ $k ]['forme'] = array_values( array_unique( array_merge( $o['forme'], $familie[ $o['id'] ] ) ) );
		}
	}
	$facuti = array();
	$bucati = preg_split( '/(<[^>]+>)/u', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
	$adanc  = 0;
	foreach ( $bucati as $i => $b ) {
		if ( '' === $b ) {
			continue;
		}
		if ( '<' === $b[0] ) {
			// La fiecare paragraf nou, fiecare om poate fi legat din nou (prima apariție din paragraf).
			if ( preg_match( '/^<\/(p|li|blockquote)>/i', $b ) ) {
				$facuti = array();
			}
			if ( preg_match( '/^<(a|h[1-6])\b/i', $b ) ) {
				$adanc++;
			} elseif ( preg_match( '/^<\/(a|h[1-6])>/i', $b ) ) {
				$adanc = max( 0, $adanc - 1 );
			}
			continue;
		}
		if ( $adanc ) {
			continue;
		}
		foreach ( $oameni as $o ) {
			if ( isset( $facuti[ $o['id'] ] ) ) {
				continue;
			}
			usort( $o['forme'], function ( $x, $y ) { return mb_strlen( $y ) - mb_strlen( $x ); } );
			foreach ( $o['forme'] as $f ) {
				$re = ps_child_re_nume( $f );
				if ( preg_match( $re, $b ) ) {
					$b = preg_replace( $re, '<a class="ps-link-om" href="' . esc_url( $o['url'] ) . '">$0</a>', $b, 1 );
					$facuti[ $o['id'] ] = true;
					break;
				}
			}
		}
		$bucati[ $i ] = $b;
	}
	return implode( '', $bucati );
}

add_filter( 'the_content', function ( $content ) {
	$p = get_post();
	if ( $p && 'post' === $p->post_type && ! is_admin() ) {
		$content = ps_child_legaturi_interne( $content );
	}
	return $content;
}, 20 );

/**
 * La publicarea unei ciorne importate (cronică, știre), WordPress ar pune data de azi.
 * Păstrăm data evenimentului, salvată la import în „_ps_data_publicare”.
 */
add_filter( 'wp_insert_post_data', function ( $data, $postarr ) {
	if ( empty( $postarr['ID'] ) || 'post' !== $data['post_type'] || 'publish' !== $data['post_status'] ) {
		return $data;
	}
	$data_eveniment = get_post_meta( (int) $postarr['ID'], '_ps_data_publicare', true );
	if ( $data_eveniment && 'publish' !== get_post_status( (int) $postarr['ID'] ) ) {
		$data['post_date']     = $data_eveniment;
		$data['post_date_gmt'] = get_gmt_from_date( $data_eveniment );
	}
	return $data;
}, 10, 2 );

/**
 * Listele de articole: tema folosește dimensiunea „atleticos-blog” (500×300, decupată din centru),
 * care taie marginile copertelor noastre (1200×630) și e neclară în cardurile mari.
 * Folosim imaginea „large” (necroită), iar CSS-ul o aliniază la stânga, unde e textul copertei.
 */
add_filter( 'post_thumbnail_size', function ( $size ) {
	return 'atleticos-blog' === $size ? 'large' : $size;
} );


/**
 * Fotografiile jucătorilor în articole.
 * Pentru fiecare articol (post) se caută numele jucătorilor cu fotografie din „Echipa” (post type team):
 * numele complet, iar pentru numele de familie distinctive și doar numele de familie („Bancu”, „Al Hamlawi”).
 *  - pe bannerul articolului (imaginea reprezentativă, pe pagina articolului) apar până la 3 fotografii;
 *  - în text, după primul paragraf, apare banda „În acest articol”, cu până la 8 jucători, cu link spre pagina lor.
 */
function ps_child_jucatori_foto() {
	$cache = get_transient( 'ps_jucatori_foto4' );
	if ( is_array( $cache ) ) {
		return $cache;
	}
	// Nume de familie prea comune sau ambigue: doar numele complet.
	$ambigue = array( 'Popescu', 'Maxim', 'Muntean', 'Tudor', 'Rădulescu' );
	$porecle = ps_child_porecle();
	$out     = array();
	foreach ( get_posts( array( 'post_type' => 'team', 'post_status' => 'publish', 'numberposts' => -1, 'ps_toti' => true ) ) as $o ) {
		if ( ! has_post_thumbnail( $o ) ) {
			continue;
		}
		$titlu = trim( preg_replace( '/\s+/', ' ', $o->post_title ) );
		$parti = explode( ' ', $titlu );
		$alias = array( $titlu, remove_accents( $titlu ) );
		if ( count( $parti ) >= 2 ) {
			$familie = implode( ' ', array_slice( $parti, 1 ) );
			if ( ! in_array( $familie, $ambigue, true ) && mb_strlen( $familie ) >= 3 ) {
				$alias[] = $familie;
				$alias[] = remove_accents( $familie );
			}
		}
		if ( isset( $porecle[ $titlu ] ) ) {
			$alias = array_merge( $alias, $porecle[ $titlu ] );
		}
		$poza = get_the_post_thumbnail_url( $o, 'medium_large' );
		$out[] = array(
			'id'    => $o->ID,
			'nume'  => $titlu,
			'url'   => get_permalink( $o ),
			'poza'  => $poza ? $poza : get_the_post_thumbnail_url( $o, 'full' ),
			'alias' => array_values( array_unique( $alias ) ),
		);
	}
	set_transient( 'ps_jucatori_foto4', $out, HOUR_IN_SECONDS );
	return $out;
}
add_action( 'save_post_team', function () { delete_transient( 'ps_jucatori_foto4' ); } );

/** Jucătorii pomeniți în textul unui articol, în ordinea importanței (de câte ori apar, apoi prima apariție). */
function ps_child_jucatori_din_text( $html ) {
	static $memo = array();
	$cheie = md5( $html );
	if ( isset( $memo[ $cheie ] ) ) {
		return $memo[ $cheie ];
	}
	// Fără secțiunea „Surse” și fără etichete HTML.
	$text = preg_replace( '#<p[^>]*>\s*<em>Surse:</em>.*?</p>#su', '', $html );
	$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' );
	// Fără diacritice: „Stevanović” = „Stevanovic”, „Cicâldău” = „Cicaldau”.
	$text   = remove_accents( $text );
	$gasiti = array();
	foreach ( ps_child_jucatori_foto() as $j ) {
		$total = 0;
		$prima = PHP_INT_MAX;
		foreach ( array_unique( array_map( 'remove_accents', $j['alias'] ) ) as $a ) {
			if ( preg_match_all( '/(?<![\p{L}\p{M}])' . preg_quote( $a, '/' ) . '(?![\p{L}\p{M}])/u', $text, $m, PREG_OFFSET_CAPTURE ) ) {
				$total += count( $m[0] );
				$prima  = min( $prima, $m[0][0][1] );
			}
		}
		if ( $total ) {
			$j['aparitii'] = $total;
			$j['prima']    = $prima;
			$gasiti[]      = $j;
		}
	}
	usort( $gasiti, function ( $a, $b ) {
		return $b['aparitii'] <=> $a['aparitii'] ?: $a['prima'] <=> $b['prima'];
	} );
	return $memo[ $cheie ] = $gasiti;
}

function ps_child_e_articolul_curent( $post_id ) {
	return is_singular( 'post' ) && (int) $post_id === (int) get_queried_object_id();
}

/* Banda „În acest articol”, după primul paragraf al textului. */
add_filter( 'the_content', function ( $content ) {
	$p = get_post();
	if ( ! $p || ! ps_child_e_articolul_curent( $p->ID ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}
	$jucatori = array_slice( ps_child_jucatori_din_text( $p->post_content ), 0, 8 );
	if ( ! $jucatori ) {
		return $content;
	}
	usort( $jucatori, function ( $a, $b ) { return $a['prima'] <=> $b['prima']; } );
	$banda = '<div class="ps-in-articol"><span class="ps-in-articol-titlu">În acest articol</span><div class="ps-in-articol-lista">';
	foreach ( $jucatori as $j ) {
		$banda .= '<a class="ps-in-articol-jucator" href="' . esc_url( ps_child_url_articole_despre( get_post( $j['id'] ) ) ) . '">'
			. '<span class="ps-in-articol-foto"><img src="' . esc_url( $j['poza'] ) . '" alt="' . esc_attr( $j['nume'] ) . '" loading="lazy"></span>'
			. '<span class="ps-in-articol-nume">' . esc_html( $j['nume'] ) . '</span></a>';
	}
	$banda .= '</div></div>';
	// După primul paragraf care nu e semnătura („de … · data”).
	$poz = 0;
	if ( preg_match_all( '#</p>#i', $content, $m, PREG_OFFSET_CAPTURE ) ) {
		foreach ( $m[0] as $sf ) {
			$inainte = substr( $content, 0, $sf[1] );
			if ( false === strpos( substr( $inainte, strrpos( $inainte, '<p' ) ), 'ps-semnatura' ) ) {
				$poz = $sf[1] + 4;
				break;
			}
		}
	}
	return $poz ? substr( $content, 0, $poz ) . $banda . substr( $content, $poz ) : $banda . $content;
}, 25 );

/* Bannerul articolului și previzualizările din liste: fotografiile jucătorilor în colțul din dreapta-jos al imaginii.
 * Cel mult 12 (3 coloane × 4 rânduri), în ordinea apariției în articol; în liste, fără nume. */
add_filter( 'post_thumbnail_html', function ( $html, $post_id ) {
	if ( ! $html || is_admin() || is_feed() || wp_is_json_request() ) {
		return $html;
	}
	$p = get_post( $post_id );
	if ( ! $p || 'post' !== $p->post_type ) {
		return $html;
	}
	// Copertele rubricilor (Florin, George) au fotografia autorului în dreapta: bulinele stau pe un rând jos, peste ea (cel mult 8).
	$rubrica  = has_category( array( 'Poveștile lui Florin', 'Penalty cu George' ), $p );
	$curent   = ps_child_e_articolul_curent( $post_id );
	$jucatori = array_slice( ps_child_jucatori_din_text( $p->post_content ), 0, $rubrica ? 8 : 12 );
	if ( ! $jucatori ) {
		return $html;
	}
	// Toți jucătorii la fel de importanți: aceeași mărime, în ordinea în care apar în articol.
	usort( $jucatori, function ( $a, $b ) { return $a['prima'] <=> $b['prima']; } );
	$poze = '';
	foreach ( $jucatori as $j ) {
		$interior = '<span class="ps-banner-foto"><img src="' . esc_url( $j['poza'] ) . '" alt="' . esc_attr( $j['nume'] ) . '" loading="lazy"></span><span class="ps-banner-nume">' . esc_html( ps_child_nume_familie( $j['nume'] ) ) . '</span>';
		// Pe pagina articolului, fiecare bulină duce la „Articole despre …”; în liste, toată coperta e deja legătură spre articol.
		$poze .= $curent
			? '<a class="ps-banner-jucator" href="' . esc_url( ps_child_url_articole_despre( get_post( $j['id'] ) ) ) . '" title="Articole despre ' . esc_attr( $j['nume'] ) . '">' . $interior . '</a>'
			: '<span class="ps-banner-jucator">' . $interior . '</span>';
	}
	$clase = 'ps-banner ps-banner-' . count( $jucatori ) . ( $curent ? ' ps-banner-articol' : ' ps-banner-lista' ) . ( $rubrica ? ' ps-banner-rubrica' : '' );
	return '<span class="' . $clase . '">' . $html . '<span class="ps-banner-jucatori">' . $poze . '</span></span>';
}, 10, 2 );

/**
 * POST /wp-json/ps/v1/tema – actualizează tema copil din depozitul de conținut (tema/atleticos-child.zip, ramura main).
 * Doar pentru administratori (update_themes). Sursa e fixă: arhiva din depozitul blogului, verificată cu SHA-256 din tema/sha256.txt.
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'ps/v1', '/tema', array(
		'methods'             => 'POST',
		'permission_callback' => function () { return current_user_can( 'update_themes' ); },
		'callback'            => 'ps_child_actualizeaza_tema',
	) );
} );

function ps_child_actualizeaza_tema() {
	$baza = 'https://raw.githubusercontent.com/acabalcescu-cloud/povestilestiintei-continut/main/tema/';
	$sha  = wp_remote_get( $baza . 'sha256.txt?nocache=' . time(), array( 'timeout' => 30 ) );
	if ( is_wp_error( $sha ) || 200 !== wp_remote_retrieve_response_code( $sha ) ) {
		return new WP_Error( 'ps_tema', 'Nu pot citi tema/sha256.txt din depozit.', array( 'status' => 502 ) );
	}
	$asteptat = strtolower( trim( strtok( wp_remote_retrieve_body( $sha ), " \n" ) ) );

	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/theme.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	$fisier = download_url( $baza . 'atleticos-child.zip?nocache=' . time(), 120 );
	if ( is_wp_error( $fisier ) ) {
		return $fisier;
	}
	if ( ! hash_equals( $asteptat, hash_file( 'sha256', $fisier ) ) ) {
		@unlink( $fisier );
		return new WP_Error( 'ps_tema', 'Arhiva nu corespunde cu sha256.txt; n-am instalat nimic.', array( 'status' => 409 ) );
	}
	$inainte  = wp_get_theme( 'atleticos-child' )->get( 'Version' );
	$upgrader = new Theme_Upgrader( new WP_Ajax_Upgrader_Skin() );
	$rezultat = $upgrader->install( $fisier, array( 'overwrite_package' => true, 'clear_update_cache' => true ) );
	@unlink( $fisier );
	if ( is_wp_error( $rezultat ) || ! $rezultat ) {
		$err = is_wp_error( $rezultat ) ? $rezultat->get_error_message() : implode( '; ', (array) $upgrader->skin->get_error_messages() );
		return new WP_Error( 'ps_tema', 'Instalarea a eșuat: ' . $err, array( 'status' => 500 ) );
	}
	wp_clean_themes_cache();
	delete_transient( 'ps_jucatori_foto4' );
	if ( function_exists( 'opcache_reset' ) ) {
		@opcache_reset();
	}
	do_action( 'litespeed_purge_all' );
	return array( 'inainte' => $inainte, 'acum' => wp_get_theme( 'atleticos-child' )->get( 'Version' ) );
}

/** POST /wp-json/ps/v1/cache – golește cache-ul LiteSpeed (doar administratori). */
add_action( 'rest_api_init', function () {
	register_rest_route( 'ps/v1', '/cache', array(
		'methods'             => 'POST',
		'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		'callback'            => function () {
			do_action( 'litespeed_purge_all' );
			// Și sitemap-ul Rank Math, ca regulile noi (ce intră / nu intră în Google) să se vadă imediat.
			if ( class_exists( '\\RankMath\\Sitemap\\Cache' ) ) {
				\RankMath\Sitemap\Cache::invalidate_storage();
			}
			return array( 'golit' => (bool) has_action( 'litespeed_purge_all' ) );
		},
	) );
} );

/** Numele de familie, pentru etichetele scurte de pe imagine („Laurențiu Popescu” → „Popescu”). */
function ps_child_nume_familie( $nume ) {
	$parti = explode( ' ', trim( $nume ) );
	return count( $parti ) > 1 ? implode( ' ', array_slice( $parti, 1 ) ) : $nume;
}

/**
 * [ps_legende] – arhiva „Legendele Științei”: cele 8 epoci, loturi istorice, fișe și lista jucătorilor.
 * Conținutul e generat din depozitul de conținut (arhiva/legende.json) în arhiva-legende.html.
 */
add_shortcode( 'ps_legende', function () {
	$f = get_stylesheet_directory() . '/arhiva-legende.html';
	return file_exists( $f ) ? file_get_contents( $f ) : '';
} );

/**
 * [ps_george limita="12"] – rubrica „Penalty cu George – Fără ezitare, de partea Științei”:
 * același carusel ca la „Poveștile lui Florin”, cu fotografia lui George.
 */
add_shortcode( 'ps_george', function ( $atts ) {
	$atts = shortcode_atts( array( 'limita' => 12 ), $atts );
	$cat  = (int) get_cat_ID( 'Penalty cu George' );
	if ( ! $cat ) {
		return '';
	}
	$query = new WP_Query( array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => (int) $atts['limita'],
		'cat'                 => $cat,
		'ignore_sticky_posts' => true,
	) );
	if ( ! $query->have_posts() ) {
		// Fără articole încă: secțiunea de pe prima pagină (clasa ps-sec-george) rămâne ascunsă.
		return '<style>.ps-sec-george{display:none !important}</style>';
	}
	$f    = get_stylesheet_directory() . '/assets/george-penalty.png';
	$foto = esc_url( get_stylesheet_directory_uri() . '/assets/george-penalty.png?v=' . filemtime( $f ) );
	ob_start();
	echo '<div class="ps-florin ps-george"><button type="button" class="ps-florin-nav ps-florin-prev" aria-label="Înapoi">&larr;</button><div class="ps-florin-track">';
	while ( $query->have_posts() ) {
		$query->the_post();
		echo '<a class="ps-florin-card" href="' . esc_url( get_permalink() ) . '">'
			. '<img class="ps-florin-foto" src="' . $foto . '" alt="George" loading="lazy">'
			. '<span class="ps-florin-text"><span class="ps-florin-autor">Penalty cu George</span>'
			. '<span class="ps-florin-titlu">' . esc_html( get_the_title() ) . '</span>'
			. '<span class="ps-florin-data">' . esc_html( get_the_date() ) . '</span></span></a>';
	}
	echo '</div><button type="button" class="ps-florin-nav ps-florin-next" aria-label="Înainte">&rarr;</button></div>';
	wp_reset_postdata();
	if ( ! has_action( 'wp_footer', 'ps_child_florin_script' ) ) {
		add_action( 'wp_footer', 'ps_child_florin_script', 99 );
	}
	return ob_get_clean();
} );

/**
 * GET/POST /ps/v1/prima-pagina – citește / înlocuiește structura Elementor a primei pagini.
 * La POST, versiunea anterioară se păstrează în meta `_ps_elementor_backup` (ultimele 5).
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'ps/v1', '/prima-pagina', array(
		array(
			'methods'             => 'GET',
			'permission_callback' => function () { return current_user_can( 'manage_options' ); },
			'callback'            => function () {
				$id = (int) get_option( 'page_on_front' );
				return array( 'id' => $id, 'data' => json_decode( (string) get_post_meta( $id, '_elementor_data', true ), true ) );
			},
		),
		array(
			'methods'             => 'POST',
			'permission_callback' => function () { return current_user_can( 'manage_options' ); },
			'callback'            => function ( WP_REST_Request $req ) {
				$id   = (int) get_option( 'page_on_front' );
				$data = $req->get_param( 'data' );
				if ( ! $id || ! is_array( $data ) || ! $data ) {
					return new WP_Error( 'ps_prima', 'Lipsește structura paginii.', array( 'status' => 400 ) );
				}
				$vechi = (string) get_post_meta( $id, '_elementor_data', true );
				$bk    = get_post_meta( $id, '_ps_elementor_backup', true );
				$bk    = is_array( $bk ) ? $bk : array();
				array_unshift( $bk, array( 'data' => $vechi, 'la' => current_time( 'mysql' ) ) );
				update_post_meta( $id, '_ps_elementor_backup', array_slice( $bk, 0, 5 ) );
				update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( $data ) ) );
				if ( class_exists( '\\Elementor\\Plugin' ) ) {
					\Elementor\Plugin::$instance->files_manager->clear_cache();
				}
				clean_post_cache( $id );
				return array( 'id' => $id, 'sectiuni' => count( $data ), 'backup' => count( $bk ) );
			},
		),
	) );
} );

/**
 * [ps_arhiva_video] – pagina „Arhiva video”: înregistrări YouTube pe epoci (date în depozit: arhiva/video/).
 */
add_shortcode( 'ps_arhiva_video', function () {
	$f = get_stylesheet_directory() . '/arhiva-video.html';
	return file_exists( $f ) ? file_get_contents( $f ) : '';
} );

/**
 * [ps_shorts ids="id1,id2" titluri="Titlu 1|Titlu 2"] – clipuri verticale YouTube (Shorts) într-un articol.
 * Imaginea se vede direct; playerul se încarcă doar la click (youtube-nocookie).
 */
add_shortcode( 'ps_shorts', function ( $atts ) {
	$atts = shortcode_atts( array( 'ids' => '', 'titluri' => '' ), $atts );
	$ids  = array_filter( array_map( 'trim', explode( ',', $atts['ids'] ) ), function ( $i ) { return preg_match( '/^[A-Za-z0-9_-]{11}$/', $i ); } );
	$tit  = array_map( 'trim', explode( '|', $atts['titluri'] ) );
	if ( ! $ids ) {
		return '';
	}
	$out = '<div class="ps-shorts">';
	foreach ( array_values( $ids ) as $k => $id ) {
		$t    = isset( $tit[ $k ] ) && '' !== $tit[ $k ] ? $tit[ $k ] : 'Clip video';
		$out .= '<figure class="ps-short"><button type="button" class="ps-short-play" data-id="' . esc_attr( $id ) . '" aria-label="Pornește: ' . esc_attr( $t ) . '">'
			. '<img src="https://i.ytimg.com/vi/' . esc_attr( $id ) . '/oar2.jpg" onerror="this.onerror=null;this.src=\'https://i.ytimg.com/vi/' . esc_attr( $id ) . '/hqdefault.jpg\'" alt="" loading="lazy"><span class="ps-vid-btn" aria-hidden="true"></span></button>'
			. '<figcaption>' . esc_html( $t ) . '</figcaption></figure>';
	}
	$out .= '</div>';
	if ( ! has_action( 'wp_footer', 'ps_child_shorts_script' ) ) {
		add_action( 'wp_footer', 'ps_child_shorts_script', 99 );
	}
	return $out;
} );
function ps_child_shorts_script() {
	echo "<script>document.querySelectorAll('.ps-short-play').forEach(function(b){b.addEventListener('click',function(){var f=document.createElement('iframe');f.src='https://www.youtube-nocookie.com/embed/'+b.dataset.id+'?autoplay=1&rel=0';f.title=b.getAttribute('aria-label');f.allow='autoplay; encrypted-media; picture-in-picture; fullscreen';f.allowFullscreen=true;f.className='ps-short-frame';b.replaceWith(f);});});</script>";
}

/**
 * „Ne găsești aici:” – rețelele Poveștile Științei, la finalul fiecărui articol.
 */
function ps_child_retele() {
	return array(
		array( 'site', 'https://povestilestiintei.ro/', 'povestilestiintei.ro', '<i class="fas fa-globe" aria-hidden="true"></i>' ),
		array( 'youtube', 'https://www.youtube.com/@PovestileStiintei', '@PovestileStiintei', '<i class="fab fa-youtube" aria-hidden="true"></i>' ),
		array( 'facebook', 'https://www.facebook.com/povestile.stiintei', 'povestile.stiintei', '<i class="fab fa-facebook-f" aria-hidden="true"></i>' ),
		array( 'instagram', 'https://www.instagram.com/povestile.stiintei/', 'povestile.stiintei', '<i class="fab fa-instagram" aria-hidden="true"></i>' ),
		array( 'tiktok', 'https://www.tiktok.com/@povestilestiintei', '@povestilestiintei', '<i class="fab fa-tiktok" aria-hidden="true"></i>' ),
		array( 'x', 'https://x.com/stiintei', 'stiintei', '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z"/></svg>' ),
		array( 'email', 'mailto:contact@povestilestiintei.ro', 'contact@povestilestiintei.ro', '<i class="fas fa-envelope" aria-hidden="true"></i>' ),
	);
}
add_filter( 'the_content', function ( $content ) {
	if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}
	$nume = array( 'site' => 'Site', 'youtube' => 'YouTube', 'facebook' => 'Facebook', 'instagram' => 'Instagram', 'tiktok' => 'TikTok', 'x' => 'X', 'email' => 'Email' );
	$out  = '<div class="ps-retele"><span class="ps-retele-titlu">Ne găsești aici:</span><div class="ps-retele-lista">';
	foreach ( ps_child_retele() as $r ) {
		$out .= '<a class="ps-retea ps-retea-' . esc_attr( $r[0] ) . '" href="' . esc_url( $r[1], array( 'https', 'mailto' ) ) . '"' . ( 'email' === $r[0] ? '' : ' target="_blank" rel="noopener"' ) . ' aria-label="' . esc_attr( $nume[ $r[0] ] . ': ' . $r[2] ) . '">'
			. '<span class="ps-retea-icon">' . $r[3] . '</span><span class="ps-retea-nume">' . esc_html( $r[2] ) . '</span></a>';
	}
	return $content . $out . '</div></div>';
}, 40 );

/* Rețelele sociale în subsolul site-ului, deasupra textului cu drepturile rezervate. */
add_action( 'wp_footer', function () {
	$nume = array( 'site' => 'Site', 'youtube' => 'YouTube', 'facebook' => 'Facebook', 'instagram' => 'Instagram', 'tiktok' => 'TikTok', 'x' => 'X', 'email' => 'Email' );
	$out  = '<div class="ps-subsol-retele" id="ps-subsol-retele">';
	foreach ( ps_child_retele() as $r ) {
		if ( 'site' === $r[0] ) {
			continue;
		}
		$out .= '<a class="ps-retea-' . esc_attr( $r[0] ) . '" href="' . esc_url( $r[1], array( 'https', 'mailto' ) ) . '"' . ( 'email' === $r[0] ? '' : ' target="_blank" rel="noopener"' ) . ' aria-label="' . esc_attr( $nume[ $r[0] ] . ': ' . $r[2] ) . '" title="' . esc_attr( $nume[ $r[0] ] . ': ' . $r[2] ) . '"><span class="ps-retea-icon">' . $r[3] . '</span></a>';
	}
	echo $out . '</div>';
	echo "<script>(function(){var r=document.getElementById('ps-subsol-retele'),c=document.querySelector('.copyright-block .container');if(r&&c){c.insertBefore(r,c.firstChild);}})();</script>";
}, 5 );

/**
 * „Articole despre <jucător>”: fișa jucătorului (ca în pagina lui din Echipa), deasupra listei de articole.
 */
add_action( 'atleticos_wrapper_open', function () {
	if ( ! ps_child_e_articole_despre() ) {
		return;
	}
	$om = absint( $_GET['om'] ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $om || 'team' !== get_post_type( $om ) || 'publish' !== get_post_status( $om ) ) {
		return;
	}
	$fisa = ps_child_jucator_fisa( $om );
	// Numele lui din biografie nu trimite spre pagina pe care suntem deja.
	$fisa = preg_replace( '#<a [^>]*href="[^"]*[?&](?:amp;|\#038;)?om=' . $om . '(?:[&"][^>]*)?>(.*?)</a>#s', '$1', $fisa );
	echo '<section class="ps-despre-jucator">' . $fisa . '</section>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escapat în funcție
	echo '<div class="ps-despre-titlu"><span>Articole despre ' . esc_html( get_the_title( $om ) ) . '</span></div>';
}, 1 );

/* Firul de navigare la căutare, în română: „Articole despre …” sau „Rezultatele căutării pentru …”. */
add_filter( 'gettext', function ( $t, $text, $domain ) {
	if ( false !== strpos( $text, 'Search results for' ) ) {
		if ( ! empty( $_GET['om'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return preg_replace( "/Search results for\s*(?:&#0?39;|'|&#8216;)?(.*?)(?:&#0?39;|'|&#8217;)?$/s", 'Articole despre $1', $text );
		}
		return str_replace( 'Search results for', 'Rezultatele căutării pentru', $text );
	}
	return $t;
}, 10, 3 );

/**
 * Membrul echipei după un nume scris oricum (Sofascore: „Assad Al-Hamlawi”, „N. Stevanović”, „Heriberto Tavares”):
 * fără diacritice și cratime; întâi numele complet, apoi numele de familie, apoi poreclele.
 */
function ps_child_om_dupa_nume( $nume ) {
	$norm = function ( $s ) { return trim( preg_replace( '/[^a-z ]+/', ' ', strtolower( remove_accents( str_replace( '-', ' ', $s ) ) ) ) ); };
	$cauta = preg_replace( '/\s+/', ' ', $norm( $nume ) );
	if ( '' === $cauta ) {
		return 0;
	}
	$oameni = get_posts( array( 'post_type' => 'team', 'post_status' => 'publish', 'numberposts' => -1, 'ps_toti' => true ) );
	$famil  = array();
	foreach ( $oameni as $o ) {
		$t = preg_replace( '/\s+/', ' ', $norm( $o->post_title ) );
		if ( $t === $cauta ) {
			return $o->ID;
		}
		foreach ( ps_child_porecle()[ trim( $o->post_title ) ] ?? array() as $p ) {
			if ( preg_replace( '/\s+/', ' ', $norm( $p ) ) === $cauta ) {
				return $o->ID;
			}
		}
		$parti = explode( ' ', $t );
		$famil[ $o->ID ] = implode( ' ', array_slice( $parti, 1 ) );
	}
	// Numele de familie: „N. Stevanovic”, „Al Hamlawi”, „Heriberto Tavares” → potrivire unică după familie.
	$p = explode( ' ', $cauta );
	foreach ( array( implode( ' ', array_slice( $p, 1 ) ), end( $p ) ) as $fam ) {
		if ( strlen( $fam ) < 3 ) {
			continue;
		}
		$gasiti = array_keys( array_filter( $famil, function ( $f ) use ( $fam ) { return $f === $fam || substr( ' ' . $f, -strlen( $fam ) - 1 ) === ' ' . $fam; } ) );
		if ( 1 === count( $gasiti ) ) {
			return $gasiti[0];
		}
	}
	return 0;
}

/**
 * [ps_jucator_video nume="Simon Elisor"] – video-ul jucătorului din fișa lui (sau fotografia), cu numele și legătura spre fișă.
 */
add_shortcode( 'ps_jucator_video', function ( $atts ) {
	$a  = shortcode_atts( array( 'nume' => '' ), $atts );
	$id = ps_child_om_dupa_nume( $a['nume'] );
	if ( ! $id ) {
		return '';
	}
	$video = function_exists( 'fw_get_db_post_option' ) ? ( fw_get_db_post_option( $id, 'hover-video' )['url'] ?? '' ) : '';
	$poza  = get_the_post_thumbnail_url( $id, 'large' );
	$titlu = get_the_title( $id );
	$media = $video
		? '<video src="' . esc_url( $video ) . '" poster="' . esc_url( $poza ) . '" muted playsinline autoplay loop preload="metadata" aria-label="' . esc_attr( $titlu ) . '"></video>'
		: ( $poza ? '<img src="' . esc_url( $poza ) . '" alt="' . esc_attr( $titlu ) . '" loading="lazy">' : '' );
	if ( ! $media ) {
		return '';
	}
	return '<figure class="ps-gol-jucator">' . $media . '<figcaption><a href="' . esc_url( ps_child_url_articole_despre( get_post( $id ) ) ) . '">' . esc_html( $titlu ) . '</a></figcaption></figure>';
} );

/**
 * POST /ps/v1/live { data: "AAAA-LL-ZZ", scor: [gazde, oaspeti], gazde?: [{nume, minut}], oaspeti?: [...], stare?: "Pauză" }
 * Scorul și marcatorii în timpul meciului, în pagina meciului (fără să schimbe statusul postării).
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'ps/v1', '/live', array(
		'methods'             => 'POST',
		'permission_callback' => function () { return current_user_can( 'edit_others_posts' ); },
		'callback'            => function ( WP_REST_Request $req ) {
			$m  = (array) $req->get_json_params();
			$id = ps_child_meci_din_data( $m['data'] ?? '' );
			if ( ! $id ) {
				return new WP_Error( 'ps_live', 'Niciun meci în ziua respectivă.', array( 'status' => 404 ) );
			}
			if ( isset( $m['scor'] ) && is_array( $m['scor'] ) && 2 === count( $m['scor'] ) && function_exists( 'fw_set_db_post_option' ) ) {
				fw_set_db_post_option( $id, 'team-1-score', (string) (int) $m['scor'][0] );
				fw_set_db_post_option( $id, 'team-2-score', (string) (int) $m['scor'][1] );
			}
			if ( isset( $m['gazde'] ) || isset( $m['oaspeti'] ) ) {
				ps_child_set_marcatori( $id, $m );
			}
			update_post_meta( $id, '_ps_live', sanitize_text_field( $m['stare'] ?? '' ) );
			clean_post_cache( $id );
			return array( 'meci' => $id, 'scor' => array( fw_get_db_post_option( $id, 'team-1-score' ), fw_get_db_post_option( $id, 'team-2-score' ) ), 'marcatori' => get_post_meta( $id, '_ps_marcatori', true ), 'stare' => get_post_meta( $id, '_ps_live', true ), 'url' => get_permalink( $id ) );
		},
	) );
} );

/* „Următorul meci” de pe prima pagină: după fluierul de start, scorul live în locul liniuțelor. */
add_filter( 'elementor/widget/render_content', function ( $html, $widget ) {
	if ( 'football-upcoming' !== $widget->get_name() || ! function_exists( 'fw_get_db_post_option' ) ) {
		return $html;
	}
	$id = ps_child_meci_din_data( wp_date( 'Y-m-d' ) );
	if ( ! $id || get_post_time( 'U', true, $id ) > time() ) {
		return $html;
	}
	// Doar dacă în casetă e chiar meciul de azi (după 2 ore, caseta trece la meciul următor).
	if ( false === strpos( $html, wp_date( 'j F Y', get_post_time( 'U', true, $id ) ) ) ) {
		return $html;
	}
	$g = fw_get_db_post_option( $id, 'team-1-score' );
	$o = fw_get_db_post_option( $id, 'team-2-score' );
	if ( '' === (string) $g || '' === (string) $o ) {
		return $html;
	}
	$g    = (int) $g;
	$o    = (int) $o;
	$html = str_replace( '<span class="lte-team-count">—<span>:</span>—</span>', '<span class="lte-team-count">' . $g . '<span>:</span>' . $o . '</span>', $html );
	$html = preg_replace( '#(<span class="lte-team-name lte-team-1[^"]*">.*?<span class="lte-team-count-mob">)—(</span>)#s', '${1}' . $g . '$2', $html, 1 );
	$html = preg_replace( '#(<span class="lte-team-name lte-team-2[^"]*"><span class="lte-team-count-mob">)—(</span>)#s', '${1}' . $o . '$2', $html, 1 );
	$stare = (string) get_post_meta( $id, '_ps_live', true );
	$eticheta = 'Final' === $stare ? 'Final' : 'Live' . ( '' !== $stare ? ' · ' . $stare : '' );
	return str_replace( '>Următorul meci</span>', '>' . esc_html( $eticheta ) . '</span>', $html );
}, 10, 2 );

/**
 * Scorul live din LiveScore (date publice, fără cheie), pentru meciul de azi:
 * scorul, marcatorii și eticheta („Live · 55'”, „Pauză”, „Final”) în pagina meciului și pe prima pagină.
 * GET /ps/v1/live-sync – îl apelează rutina de pe Mac la 2 minute; cel mult o interogare LiveScore pe minut.
 */
function ps_child_livescore_json( $url ) {
	$r = wp_remote_get( $url, array( 'timeout' => 15, 'headers' => array( 'Accept' => 'application/json' ) ) );
	return is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
}

function ps_child_livescore_sync() {
	$id = ps_child_meci_din_data( wp_date( 'Y-m-d' ) );
	if ( ! $id ) {
		return array( 'meci' => null );
	}
	$start = (int) get_post_time( 'U', true, $id );
	if ( time() < $start - 15 * MINUTE_IN_SECONDS || time() > $start + 4 * HOUR_IN_SECONDS ) {
		return array( 'meci' => $id, 'stare' => 'în afara meciului' );
	}
	if ( get_transient( 'ps_livescore_' . $id ) ) {
		// Datele de acum un minut: scorul, starea și marcatorii salvați la ultima interogare.
		return array( 'meci' => $id, 'data_text' => wp_date( 'j F Y', $start ), 'stare' => get_post_meta( $id, '_ps_live', true ), 'scor' => array( (int) fw_get_db_post_option( $id, 'team-1-score' ), (int) fw_get_db_post_option( $id, 'team-2-score' ) ), 'marcatori' => get_post_meta( $id, '_ps_marcatori', true ), 'din_cache' => true );
	}
	set_transient( 'ps_livescore_' . $id, 1, MINUTE_IN_SECONDS );

	$eid = get_post_meta( $id, '_ps_livescore_id', true );
	if ( ! $eid ) {
		$zi = ps_child_livescore_json( 'https://prod-public-api.livescore.com/v1/api/app/date/soccer/' . wp_date( 'Ymd' ) . '/3?MD=1' );
		foreach ( (array) ( $zi['Stages'] ?? array() ) as $s ) {
			foreach ( (array) ( $s['Events'] ?? array() ) as $e ) {
				foreach ( array( 'T1', 'T2' ) as $t ) {
					$nume = (string) ( $e[ $t ][0]['Nm'] ?? '' );
					if ( false !== stripos( $nume, 'Universitatea Craiova' ) && false === strpos( $nume, '1948' ) ) {
						$eid = (string) $e['Eid'];
					}
				}
			}
		}
		if ( ! $eid ) {
			return array( 'meci' => $id, 'stare' => 'negăsit în LiveScore' );
		}
		update_post_meta( $id, '_ps_livescore_id', $eid );
	}
	$inc = ps_child_livescore_json( 'https://prod-public-api.livescore.com/v1/api/app/incidents/soccer/' . rawurlencode( $eid ) . '?locale=en' );
	$sb  = ps_child_livescore_json( 'https://prod-public-api.livescore.com/v1/api/app/scoreboard/soccer/' . rawurlencode( $eid ) . '?locale=en' );
	if ( ! $sb || ! isset( $sb['Tr1'] ) ) {
		return array( 'meci' => $id, 'stare' => 'fără date' );
	}
	$noi_acasa = false !== stripos( (string) ( $sb['T1'][0]['Nm'] ?? '' ), 'Craiova' );
	$marc      = array( 'gazde' => array(), 'oaspeti' => array() );
	$h = 0;
	$a = 0;
	foreach ( (array) ( $inc['Incs'] ?? array() ) as $repriza ) {
		foreach ( (array) $repriza as $grup ) {
			foreach ( (array) ( $grup['Incs'] ?? array( $grup ) ) as $x ) {
				if ( ! in_array( (int) ( $x['IT'] ?? 0 ), array( 36, 37, 39 ), true ) || empty( $x['Sc'] ) ) {
					continue;
				}
				list( $sh, $sa ) = array( (int) $x['Sc'][0], (int) $x['Sc'][1] );
				$parte = $sh > $h ? 'gazde' : ( $sa > $a ? 'oaspeti' : '' );
				$h     = max( $h, $sh );
				$a     = max( $a, $sa );
				if ( ! $parte ) {
					continue;
				}
				$minut = (string) ( $x['Min'] ?? '' ) . ( ! empty( $x['MinEx'] ) ? '+' . $x['MinEx'] : '' );
				$nume  = trim( ( $x['Fn'] ?? '' ) . ' ' . ( $x['Ln'] ?? '' ) );
				$om    = ps_child_om_dupa_nume( $nume );
				if ( $om && ( ( 'gazde' === $parte ) === $noi_acasa ) && 39 !== (int) $x['IT'] ) {
					$nume = get_the_title( $om );
				}
				$marc[ $parte ][] = array( 'nume' => $nume . ( 39 === (int) $x['IT'] ? ' (autogol)' : ( 37 === (int) $x['IT'] ? ' (penalty)' : '' ) ), 'minut' => $minut );
			}
		}
	}
	$eps  = (string) ( $sb['Eps'] ?? '' );
	$fin  = in_array( $eps, array( 'FT', 'AET', 'AP' ), true );
	$eti  = $fin ? 'Final' : ( 'HT' === $eps ? 'Pauză' : ( 'NS' === $eps ? '' : $eps ) );
	$vechi = array( fw_get_db_post_option( $id, 'team-1-score' ), fw_get_db_post_option( $id, 'team-2-score' ), get_post_meta( $id, '_ps_marcatori', true ), get_post_meta( $id, '_ps_live', true ) );
	if ( 'NS' !== $eps && function_exists( 'fw_set_db_post_option' ) ) {
		fw_set_db_post_option( $id, 'team-1-score', (string) (int) $sb['Tr1'] );
		fw_set_db_post_option( $id, 'team-2-score', (string) (int) $sb['Tr2'] );
		ps_child_set_marcatori( $id, $marc );
		if ( 'publish' !== get_post_status( $id ) ) {
			wp_publish_post( $id );
		}
	}
	update_post_meta( $id, '_ps_live', $eti );
	$nou = array( fw_get_db_post_option( $id, 'team-1-score' ), fw_get_db_post_option( $id, 'team-2-score' ), get_post_meta( $id, '_ps_marcatori', true ), $eti );
	if ( $nou !== $vechi ) {
		clean_post_cache( $id );
		do_action( 'litespeed_purge_all' );
	}
	return array( 'meci' => $id, 'data_text' => wp_date( 'j F Y', $start ), 'livescore' => $eid, 'scor' => array( (int) $sb['Tr1'], (int) $sb['Tr2'] ), 'stare' => $eti, 'marcatori' => $marc, 'schimbat' => $nou !== $vechi );
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'ps/v1', '/live-sync', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function () { return ps_child_livescore_sync(); },
	) );
} );

/* Prima pagină, în ziua meciului: caseta „Următorul meci” își reîmprospătează singură scorul la fiecare minut (din /ps/v1/live-sync). */
add_action( 'wp_footer', function () {
	if ( ! is_front_page() ) {
		return;
	}
	?>
	<script>
	(function () {
		var box = document.querySelector('.lte-football-upcoming');
		if (!box) return;
		function pune(d) {
			if (!d || !d.scor || !d.data_text || box.textContent.indexOf(d.data_text) < 0) return;
			var c = box.querySelector('.lte-team-count');
			if (c) c.innerHTML = d.scor[0] + '<span>:</span>' + d.scor[1];
			var m = box.querySelectorAll('.lte-team-count-mob');
			if (m[0]) m[0].textContent = d.scor[0];
			if (m[1]) m[1].textContent = d.scor[1];
			var h = box.querySelector('.lte-header-upcoming');
			if (h && d.stare) h.textContent = d.stare === 'Final' ? 'Final' : 'Live · ' + d.stare;
		}
		function verifica() {
			fetch('/wp-json/ps/v1/live-sync', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (d) {
				pune(d);
				if (d && d.stare === 'Final') clearInterval(t);
			}).catch(function () {});
		}
		var t = setInterval(verifica, 60000);
		verifica();
	})();
	</script>
	<?php
}, 99 );

/* Postarea automată pe Facebook (WP2Social Auto Publish): titlul și rezumatul, în română, nu mesajul implicit în engleză. */
add_action( 'init', function () {
	$m = get_option( 'xyz_fbap_message' );
	if ( false !== $m && false !== strpos( $m, 'New post added at' ) ) {
		update_option( 'xyz_fbap_message', "{POST_TITLE}\n\n{POST_EXCERPT}\n\nHai Știința!" );
	}
} );

/* ===================== SEO (Rank Math) ===================== */

/* Titluri, descrieri și pagini: un singur loc de editat. */
function ps_child_seo_pagini() {
	return array(
		'arhiva-video'         => array( 'Arhiva video a Universității Craiova', 'Arhiva video a Universității Craiova: meciuri istorice, goluri și momente de neuitat ale Științei, adunate de pe YouTube și așezate pe ani.' ),
		'penalty-cu-george'    => array( 'Penalty cu George – opinii despre Universitatea Craiova', 'Penalty cu George: opiniile lui George Fedorovici despre meciurile, jucătorii și clubul Universitatea Craiova. Fără ezitare, de partea Științei.' ),
		'legendele-stiintei'   => array( 'Legendele Științei – jucătorii care au făcut istorie la Craiova', 'Legendele Științei: jucătorii care au scris istoria Universității Craiova, de la primii ani la Craiova Maxima și campionii de azi, epocă cu epocă.' ),
		'stiri'                => array( 'Știri Universitatea Craiova', 'Ultimele știri despre Universitatea Craiova: transferuri, accidentări, declarații, echipe de start și tot ce se întâmplă la Știința.' ),
		'cronici'              => array( 'Cronicile meciurilor Universității Craiova', 'Cronicile meciurilor Universității Craiova în SuperLiga, Cupa României și cupele europene: scor, goluri, statistici și rezumate video.' ),
		'povestile-lui-florin' => array( 'Poveștile lui Florin – Florin Stancu despre Știința', 'Poveștile lui Florin: Florin Stancu scrie despre Universitatea Craiova, despre jucători, meciuri și fotbalul de azi, cu suflet de suporter.' ),
		'despre-club'          => array( 'Despre Universitatea Craiova – istorie și palmares', 'Universitatea Craiova pe scurt: istoria clubului, palmaresul, stadionul „Ion Oblemenco” și ce înseamnă Știința pentru suporterii ei.' ),
		'echipa'               => array( 'Lotul Universității Craiova', 'Lotul Universității Craiova: portari, fundași, mijlocași și atacanți, cu fișa fiecărui jucător și articolele despre el.' ),
		'istorie'              => array( 'Istoria Universității Craiova', 'Istoria Universității Craiova: titlurile, Cupele, Craiova Maxima, semifinala UEFA din 1983 și oamenii care au făcut din Știința o legendă.' ),
	);
}
define( 'PS_SEO_SITE', 'Poveștile Științei' );
define( 'PS_SEO_HOME_TITLU', 'Poveștile Științei – blogul suporterilor Universității Craiova' );
define( 'PS_SEO_HOME_DESC', 'Blogul suporterilor Universității Craiova: știri, cronici ale meciurilor, rezumate video, statistici și istoria Științei, de la Oblemenco până azi.' );

function ps_child_seo_titlu() {
	if ( is_front_page() ) {
		return PS_SEO_HOME_TITLU;
	}
	if ( is_page() ) {
		$p = ps_child_seo_pagini();
		$s = get_post_field( 'post_name', get_queried_object_id() );
		return ( isset( $p[ $s ] ) ? $p[ $s ][0] : single_post_title( '', false ) ) . ' | ' . PS_SEO_SITE;
	}
	if ( is_singular() ) {
		return single_post_title( '', false ) . ' | ' . PS_SEO_SITE;
	}
	if ( is_category() ) {
		return single_cat_title( '', false ) . ' – Universitatea Craiova | ' . PS_SEO_SITE;
	}
	if ( is_tag() ) {
		return single_tag_title( '', false ) . ' | ' . PS_SEO_SITE;
	}
	if ( is_author() ) {
		return 'Articole de ' . get_the_author_meta( 'display_name', get_queried_object_id() ) . ' | ' . PS_SEO_SITE;
	}
	return '';
}
add_filter( 'rank_math/frontend/title', function ( $t ) {
	$n = ps_child_seo_titlu();
	return $n ? $n : $t;
}, 20 );

function ps_child_seo_descriere() {
	if ( is_front_page() ) {
		return PS_SEO_HOME_DESC;
	}
	if ( is_page() ) {
		$p = ps_child_seo_pagini();
		$s = get_post_field( 'post_name', get_queried_object_id() );
		return isset( $p[ $s ] ) ? $p[ $s ][1] : '';
	}
	if ( is_category() ) {
		$d = trim( wp_strip_all_tags( category_description() ) );
		return $d ? $d : 'Articole din categoria ' . single_cat_title( '', false ) . ' despre Universitatea Craiova, scrise de suporterii Științei pe Poveștile Științei.';
	}
	if ( is_singular( 'post' ) ) {
		$e = trim( wp_strip_all_tags( get_post_field( 'post_excerpt', get_queried_object_id() ) ) );
		return $e;
	}
	return '';
}
add_filter( 'rank_math/frontend/description', function ( $d ) {
	$n = ps_child_seo_descriere();
	return $n ? wp_html_excerpt( $n, 300, '' ) : $d;
}, 20 );

/* Pe Facebook și X: doar titlul articolului, fără numele site-ului (acela apare oricum sub link). */
foreach ( array( 'rank_math/opengraph/facebook/og_title', 'rank_math/opengraph/twitter/title' ) as $ps_f ) {
	add_filter( $ps_f, function ( $t ) {
		if ( is_front_page() ) {
			return PS_SEO_HOME_TITLU;
		}
		if ( is_page() ) {
			$p = ps_child_seo_pagini();
			$sl = get_post_field( 'post_name', get_queried_object_id() );
			if ( isset( $p[ $sl ] ) ) {
				return $p[ $sl ][0];
			}
		}
		return is_singular() ? single_post_title( '', false ) : $t;
	}, 20 );
}
foreach ( array( 'rank_math/opengraph/facebook/og_description', 'rank_math/opengraph/twitter/description' ) as $ps_f ) {
	add_filter( $ps_f, function ( $d ) {
		$n = ps_child_seo_descriere();
		return $n ? $n : $d;
	}, 20 );
}

/* Date structurate: editorul e o organizație (Poveștile Științei) cu rețelele ei; titlul articolului fără sufix; VideoObject la rezumate. */
add_filter( 'rank_math/json_ld', function ( $data ) {
	$same = array();
	foreach ( ps_child_retele() as $r ) {
		if ( ! in_array( $r[0], array( 'site', 'email' ), true ) ) {
			$same[] = $r[1];
		}
	}
	foreach ( $data as $k => $e ) {
		if ( ! is_array( $e ) || empty( $e['@type'] ) ) {
			continue;
		}
		$tip = (array) $e['@type'];
		if ( isset( $e['@id'] ) && false !== strpos( $e['@id'], '#person' ) && ! is_author() ) {
			$data[ $k ]['@type']  = 'Organization';
			$data[ $k ]['name']   = PS_SEO_SITE;
			$data[ $k ]['sameAs'] = $same;
			$data[ $k ]['email']  = 'contact@povestilestiintei.ro';
		}
		if ( 'WebSite' === $tip[0] ) {
			$data[ $k ]['name']          = PS_SEO_SITE;
			$data[ $k ]['alternateName'] = 'Poveștile Științei | suporterii Universitatea Craiova';
		}
		if ( is_singular( 'post' ) && array_intersect( $tip, array( 'NewsArticle', 'BlogPosting', 'Article' ) ) ) {
			$data[ $k ]['headline'] = wp_html_excerpt( single_post_title( '', false ), 110, '' );
			$data[ $k ]['name']     = single_post_title( '', false );
			$data[ $k ]['about']    = array( '@type' => 'SportsTeam', 'name' => 'Universitatea Craiova', 'sport' => 'Fotbal' );
		}
	}
	if ( is_singular( 'post' ) && 'video' === get_post_format() ) {
		$post = get_queried_object();
		$url  = trim( wp_strip_all_tags( $post->post_content ) );
		if ( preg_match( '~(?:v=|youtu\.be/|embed/)([\w-]{11})~', $url, $m ) ) {
			$data['ps_video'] = array(
				'@type'        => 'VideoObject',
				'name'         => get_the_title( $post ),
				'description'  => wp_strip_all_tags( $post->post_excerpt ? $post->post_excerpt : get_the_title( $post ) ),
				'thumbnailUrl' => array( 'https://i.ytimg.com/vi/' . $m[1] . '/maxresdefault.jpg', 'https://i.ytimg.com/vi/' . $m[1] . '/hqdefault.jpg' ),
				'uploadDate'   => get_the_date( 'c', $post ),
				'embedUrl'     => 'https://www.youtube.com/embed/' . $m[1],
				'contentUrl'   => 'https://www.youtube.com/watch?v=' . $m[1],
				'inLanguage'   => 'ro-RO',
			);
		}
	}
	return $data;
}, 99 );

/* Ce nu are ce căuta în Google: diapozitivele sliderului și tipurile tehnice ale meciurilor. */
add_filter( 'rank_math/sitemap/exclude_post_type', function ( $exclude, $type ) {
	return in_array( $type, array( 'sliders' ), true ) ? true : $exclude;
}, 10, 2 );
add_filter( 'rank_math/sitemap/exclude_taxonomy', function ( $exclude, $tax ) {
	return in_array( $tax, array( 'sliders-category', 'lte-football-type' ), true ) ? true : $exclude;
}, 10, 2 );
add_filter( 'rank_math/frontend/robots', function ( $robots ) {
	if ( is_singular( 'sliders' ) || is_tax( array( 'sliders-category', 'lte-football-type' ) ) ) {
		$robots['index'] = 'noindex';
	}
	return $robots;
} );

/* Text alternativ pentru imaginile fără alt: titlul articolului (coperți, imagini din text). */
add_filter( 'wp_get_attachment_image_attributes', function ( $attr, $att ) {
	if ( empty( $attr['alt'] ) ) {
		$parent = $att->post_parent ? get_the_title( $att->post_parent ) : '';
		$attr['alt'] = $parent ? $parent : ( is_singular() ? single_post_title( '', false ) : PS_SEO_SITE );
	}
	return $attr;
}, 10, 2 );
add_filter( 'the_content', function ( $c ) {
	if ( ! is_singular() || false === strpos( $c, 'alt=""' ) ) {
		return $c;
	}
	return str_replace( 'alt=""', 'alt="' . esc_attr( single_post_title( '', false ) ) . '"', $c );
}, 50 );

/* Prima pagină are nevoie de un titlu H1 (pentru Google și cititoarele de ecran); vizual, pagina rămâne neschimbată. */
add_action( 'wp_body_open', function () {
	if ( is_front_page() ) {
		echo '<h1 class="screen-reader-text">' . esc_html( PS_SEO_HOME_TITLU ) . '</h1>';
	}
} );

/* Comentarii: niciun comentariu nu apare pe site până nu e aprobat din Panou > Comentarii (cererea lui George, 1 nov 2026). */
add_filter( 'pre_option_comment_moderation', function () { return '1'; } );
add_filter( 'pre_option_comment_previously_approved', function () { return '0'; } );

/* Comentarii doar cu cont: cititorii intră cu Facebook (Nextend Social Login), comentariul așteaptă aprobarea. */
add_filter( 'pre_option_comment_registration', function () { return '1'; } );
// Contul se creează doar prin Facebook; înregistrarea clasică din wp-login rămâne închisă (fără conturi de spam).
add_filter( 'nsl_is_register_allowed', '__return_true', 20 );
// Cititorii logați nu văd bara de administrare.
add_filter( 'show_admin_bar', function ( $show ) {
	return current_user_can( 'edit_posts' ) ? $show : false;
} );
add_filter( 'comment_form_defaults', function ( $d ) {
	$d['title_reply']   = 'Lasă un comentariu';
	$d['label_submit']  = 'Trimite comentariul';
	$d['must_log_in']   = '<p class="must-log-in ps-com-info">Ca să comentezi, conectează-te cu contul de Facebook. Comentariul apare pe site după ce este aprobat.</p>';
	$d['comment_notes_after'] = '<p class="ps-com-info">Comentariul tău apare pe site după ce este aprobat. Te rugăm să păstrezi un ton civilizat.</p>';
	return $d;
} );

/* Diagnoză Nextend (logare Facebook): ce App ID e salvat. Secretul nu se afișează, doar lungimea lui. Doar administratorii. */
add_action( 'rest_api_init', function () {
	register_rest_route( 'ps/v1', '/nsl', array(
		'methods'             => array( 'GET', 'POST' ),
		'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		'callback'            => function ( WP_REST_Request $r ) {
			$o = maybe_unserialize( get_option( 'nsl_facebook' ) );
			if ( is_string( $o ) ) {
				$j = json_decode( $o, true );
				$o = is_array( $j ) ? $j : array();
			}
			$o = (array) $o;
			if ( 'POST' === $r->get_method() && preg_match( '/^\d{10,20}$/', (string) $r->get_param( 'appid' ) ) ) {
				$o['appid'] = (string) $r->get_param( 'appid' );
				update_option( 'nsl_facebook', $o );
			}
			$g = maybe_unserialize( get_option( 'nextend_social_login' ) );
			return array(
				'appid'           => isset( $o['appid'] ) ? $o['appid'] : null,
				'appid_hex'       => isset( $o['appid'] ) ? bin2hex( $o['appid'] ) : null,
				'secret_lungime'  => isset( $o['secret'] ) ? strlen( $o['secret'] ) : 0,
				'tested'          => isset( $o['tested'] ) ? $o['tested'] : null,
				'activat'         => is_array( $g ) && isset( $g['enabled'] ) ? $g['enabled'] : $g,
				'tip_optiune'     => gettype( get_option( 'nsl_facebook' ) ),
			);
		},
	) );
} );
